﻿using System;
using System.Collections.Generic;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public partial class Accomodation
    {
        public int AccdId { get; set; }
        public int? BookingId { get; set; }
        public int? Hid { get; set; }
        public string City { get; set; }
        public int NoOfRooms { get; set; }
        public decimal? Price { get; set; }
        public string RoomType { get; set; }

        public virtual Booking Booking { get; set; }
        public virtual Hotel H { get; set; }
    }
}
