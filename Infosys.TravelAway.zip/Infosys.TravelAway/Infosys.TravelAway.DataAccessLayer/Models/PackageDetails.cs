﻿using System;
using System.Collections.Generic;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public partial class PackageDetails
    {
        public int DetailsId { get; set; }
        public int? PackageId { get; set; }
        public string PlacesToVisit { get; set; }
        public string Description { get; set; }
        public int Days { get; set; }
        public int Nights { get; set; }
        public string Accomodation { get; set; }
        public decimal? PricePerAdult { get; set; }

        public virtual Package Package { get; set; }
    }
}
