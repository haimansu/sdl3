﻿using System;
using System.Collections.Generic;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public partial class PackageCategory
    {
        public PackageCategory()
        {
            Package = new HashSet<Package>();
        }

        public int CategoryId { get; set; }
        public string CategoryName { get; set; }

        public virtual ICollection<Package> Package { get; set; }
    }
}
