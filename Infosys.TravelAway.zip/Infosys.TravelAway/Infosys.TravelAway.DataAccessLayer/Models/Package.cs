﻿using System;
using System.Collections.Generic;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public partial class Package
    {
        public Package()
        {
            Booking = new HashSet<Booking>();
            Hotel = new HashSet<Hotel>();
            PackageDetails = new HashSet<PackageDetails>();
        }

        public int PackageId { get; set; }
        public string PackageInfo { get; set; }
        public string PackageName { get; set; }
        public int? CategoryId { get; set; }
        public string PackageType { get; set; }

        public virtual PackageCategory Category { get; set; }
        public virtual ICollection<Booking> Booking { get; set; }
        public virtual ICollection<Hotel> Hotel { get; set; }
        public virtual ICollection<PackageDetails> PackageDetails { get; set; }
    }
}
