﻿using System;
using System.Collections.Generic;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public partial class CustomerCare
    {
        public int QueryId { get; set; }
        public int? BookingId { get; set; }
        public string Query { get; set; }
        public string QueryStatus { get; set; }
        public string Assignee { get; set; }
        public string QueryAns { get; set; }

        public virtual Booking Booking { get; set; }
    }
}
