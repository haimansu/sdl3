﻿using System;
using System.Collections.Generic;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public partial class Rating
    {
        public int Rid { get; set; }
        public string Review { get; set; }
        public int? Rating1 { get; set; }
        public int? BookingId { get; set; }

        public virtual Booking Booking { get; set; }
    }
}
