﻿using System;
using System.Collections.Generic;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public partial class Booking
    {
        public Booking()
        {
            Accomodation = new HashSet<Accomodation>();
            CustomerCare = new HashSet<CustomerCare>();
            Payment = new HashSet<Payment>();
            Rating = new HashSet<Rating>();
        }

        public string EmailId { get; set; }
        public int BookingId { get; set; }
        public decimal ContactNo { get; set; }
        public string Address { get; set; }
        public DateTime TravelDate { get; set; }
        public int NoOfAdults { get; set; }
        public int? NoOfChildren { get; set; }
        public string Status { get; set; }
        public int? PackageId { get; set; }

        public virtual Customer Email { get; set; }
        public virtual Package Package { get; set; }
        public virtual ICollection<Accomodation> Accomodation { get; set; }
        public virtual ICollection<CustomerCare> CustomerCare { get; set; }
        public virtual ICollection<Payment> Payment { get; set; }
        public virtual ICollection<Rating> Rating { get; set; }
    }
}
