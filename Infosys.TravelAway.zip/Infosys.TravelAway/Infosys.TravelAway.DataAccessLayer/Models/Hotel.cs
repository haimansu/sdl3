﻿using System;
using System.Collections.Generic;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public partial class Hotel
    {
        public Hotel()
        {
            Accomodation = new HashSet<Accomodation>();
        }

        public int Hid { get; set; }
        public string HotelName { get; set; }
        public int HotelType { get; set; }
        public decimal? SingleRoomPrice { get; set; }
        public decimal? DoubleRoomPrice { get; set; }
        public decimal? DeluxeRoomPrice { get; set; }
        public decimal? SuiteRoomPrice { get; set; }
        public string City { get; set; }
        public int? PackageId { get; set; }

        public virtual Package Package { get; set; }
        public virtual ICollection<Accomodation> Accomodation { get; set; }
    }
}
