﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Data.SqlClient;
using System.Linq;
using Infosys.TravelAway.DataAccessLayer.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Data;

namespace Infosys.TravelAway.DataAccessLayer
{
    public class TravelAwayRepository
    {

        private TravelAwayContext Context { get; set; }

        public TravelAwayRepository()
        {
            Context = new TravelAwayContext();
        }

       public string Login(string emailId, string password)
        {
            string roleName = "";
            try
            {
                Roles role = new Roles();
                Customer objUser = (from usr in Context.Customer
                                    where usr.EmailId == emailId && usr.Password == password
                                    select usr).FirstOrDefault();


                if (objUser != null)
                {
                    role = Context.Roles.Find(objUser.RoleId);
                    roleName = role.RoleName;
                   // Console.WriteLine("Role in customer" + roleName);
                }

                else if (objUser == null)
                {

                    Employee empUser = (from emp in Context.Employee
                                        where emp.EmailId == emailId && emp.Password == password
                                        select emp).FirstOrDefault();
                    if (empUser != null)
                    {
                        role = Context.Roles.Find(empUser.RoleId);
                        roleName = role.RoleName;
                        //Console.WriteLine("Role in employee" + roleName);
                    }
                    

                    else
                        roleName = "Invalid credentials";



                }
                else 
                    roleName = "Invalid credentials";
            }
            catch (Exception)
            {
                roleName = "Invalid credentials";
            }
            Console.WriteLine(roleName);
            return roleName;
        }
        public int Registration(string email, string fName, string lName, string password, string gender, decimal contact, DateTime dob, string address)
        {
            int result;
            int returnResult = -1;
            try
            {
                SqlParameter pFName = new SqlParameter("@FirstName", fName);
                SqlParameter pLName = new SqlParameter("@LastName", lName);
                SqlParameter pPassword = new SqlParameter("@Password", password);
                SqlParameter pGender = new SqlParameter("@Gender", gender);
                SqlParameter pEmail = new SqlParameter("@EmailId", email);
                SqlParameter pDob = new SqlParameter("@DOB", dob);
                SqlParameter pContact = new SqlParameter("@Contact", contact);
                SqlParameter pAddress = new SqlParameter("@Address", address);
                //SqlParameter pRoleId = new SqlParameter("@RoleId",roleId);

                SqlParameter pRetRslt = new SqlParameter("@RetRslt", System.Data.SqlDbType.Int);
            
                pRetRslt.Direction = System.Data.ParameterDirection.Output;
                result = Context.Database.ExecuteSqlRaw($"EXEC @RetRslt=usp_RegisterCustomer @EmailId,@FirstName,@LastName,@Password,@Gender,@Contact,@DOB,@Address",
                                                       pRetRslt, pEmail, pFName, pLName, pPassword, pGender, pContact, pDob, pAddress);
                if (result > 0)
                    returnResult = Convert.ToInt32(pRetRslt.Value);
            }
            catch (Exception ex)
            {
                returnResult = -99;
                Console.WriteLine(ex.Message);
            }
            return returnResult;
        }


        public List<PackageCategory> GetAllPackageCategories()
        {
            List<PackageCategory> packageCategoryList= (from package in Context.PackageCategory
                                                        select package).ToList();
            return packageCategoryList;
        }

        public List<Package> GetAllPackagesusingTVF()
        {
            List<Package> lstPackage;
            try
            {
                lstPackage = Context.Package.FromSqlRaw("select * from ufn_ViewAllPackages()").ToList();
            }
            catch(Exception)
            {
                lstPackage = null;
            }
            return lstPackage;
        }


       

        public List<Package> GetPackageByCategoryName(string categoryName)
        {
            List<Package> lstPackage = null;
            try
            {
                lstPackage = (from cats in Context.PackageCategory
                              join packs in Context.Package
                              on cats.CategoryId equals packs.CategoryId
                              where cats.CategoryName == categoryName
                              select packs).ToList();
            }
            catch (Exception)
            {
                lstPackage = null;
            }
            return lstPackage;
        }



        public List<PackageDetails> GetAllPackageDetails(string packageName)
        {
            List < PackageDetails > packageList = null;
            try
            {
                packageList = (from p in Context.PackageDetails
                               join packs in Context.Package
                               on p.PackageId equals packs.PackageId
                               where packs.PackageName == packageName
                               select p).ToList();
            }
            catch(Exception)
            {
                packageList = null;
            }
            return packageList;
        }

        public bool EditProfile(Customer cust)
        {
            bool status;
            Customer cust1 = Context.Customer.Find(cust.EmailId);
            try
            {
                        cust1.Address = cust.Address;
                        cust1.ContactNo = cust.ContactNo;
                        cust1.FirstName = cust.FirstName;
                        cust1.LastName = cust.LastName;
                        cust1.Gender = cust.Gender;
                        cust1.DateOfBirth = cust.DateOfBirth;
                    using var newContext = new TravelAwayContext();
                    newContext.Customer.Update(cust1);
                    newContext.SaveChanges();
                    status = true;

            }
            catch (Exception ex)
            {
                status = false;
                Console.WriteLine(ex.Message);
            }
            return status;
        }
        public bool Rating(Rating rate)
        {
            bool status;
            try
            {
                Rating ratingObj = new Rating
                {
                    Review = rate.Review,
                    Rating1 = rate.Rating1,
                    BookingId = rate.BookingId
                };
                Context.Rating.Add(ratingObj);
                Context.SaveChanges();
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
                Console.WriteLine(ex.Message);
            }
            return status;
        }

        public bool Payment(Payment pay)
        {
            bool status;
            try
            {
                Payment payment = new Payment();
                payment.BookingId = pay.BookingId;
                payment.TotalAmount = pay.TotalAmount;
                payment.PaymentStatus = pay.PaymentStatus;
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
                Console.WriteLine(ex.Message);
            }
            return status;
        }

        ///////////////////////RATHEESH CODE START/////////////////////////////////////
        public int BookPackage(Booking newBooking)
        {
            int status = 0;
            //  int retresult = -1;
            //Booking newbooking = new Booking();
            try
            {
                //newbooking.EmailId = emailId;
                //newbooking.PackageId = packageId;
                //newbooking.Status = bookingStatus;
                //newbooking.ContactNo = contactNo;
                //newbooking.Address = address;
                //newbooking.TravelDate = dateOfTravel;
                //newbooking.NoOfAdults = noOfAdults;
                //newbooking.NoOfChildren = noOfChildren;
                Context.Booking.Add(newBooking);
                Context.SaveChanges();
                int returnItem = (from book in Context.Booking
                                  where book.PackageId == newBooking.PackageId
                                  select book.BookingId).FirstOrDefault();
                status = returnItem;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                status = -1;
            }
            return status;
        }

        public List<Booking> BookingHistory(string emailId)
        {
            List<Booking> bookings = new List<Booking>();
            try
            {
                bookings = (from book in Context.Booking
                            where book.EmailId == emailId
                            select book).ToList();
            }
            catch (Exception)
            {

                bookings = null;
            }
            return bookings;
        }

        public Package GetPackageById(string packageId)
        {
            Package pack = new Package();
            try
            {
                int pId = Int32.Parse(packageId);

                pack = (from p in Context.Package
                        where p.PackageId == pId
                        select p).FirstOrDefault();
            }
            catch (Exception)
            {

                packageId = null;
            }
            return pack;
        }

        public int BookAccomodation(Accomodation newAccomodation)
        {
            int status = 0;
            try
            {
                Hotel findHotel = new Hotel();
                findHotel = Context.Hotel.Where(h => h.Hid == newAccomodation.Hid).FirstOrDefault();
                if (newAccomodation.RoomType == "Single")
                    newAccomodation.Price = findHotel.SingleRoomPrice * newAccomodation.NoOfRooms;
                else if (newAccomodation.RoomType == "Double")
                    newAccomodation.Price = findHotel.DoubleRoomPrice * newAccomodation.NoOfRooms;
                else if (newAccomodation.RoomType == "Deluxe")
                    newAccomodation.Price = findHotel.DeluxeRoomPrice * newAccomodation.NoOfRooms;
                else
                    newAccomodation.Price = findHotel.SuiteRoomPrice * newAccomodation.NoOfRooms;

                SqlParameter prmBookingId = new SqlParameter("@BookingId", newAccomodation.BookingId);
                SqlParameter prmCity = new SqlParameter("@City", newAccomodation.City);
                SqlParameter prmHotelId = new SqlParameter("@HId", newAccomodation.Hid);
                SqlParameter prmRoomType = new SqlParameter("@RoomType", newAccomodation.RoomType);
                SqlParameter prmNoOfRooms = new SqlParameter("@NoOfRooms", newAccomodation.NoOfRooms);
                SqlParameter prmEstimatedCost = new SqlParameter("@EstimatedCost", newAccomodation.Price);
                // SqlParameter pRetresult = new SqlParameter("@Returnresult", newAccomodation.Price);
                var result = Context.Database.ExecuteSqlRaw($"EXEC dbo.usp_AddAccommodation @BookingId,@City,@HId,@RoomType,@NoOfRooms,@EstimatedCost",
                    prmBookingId, prmCity, prmHotelId, prmRoomType, prmNoOfRooms, prmEstimatedCost);
                Context.SaveChanges();
                if (result > 0)
                    status = Context.Accomodation.Where(h => h.Hid == newAccomodation.Hid).FirstOrDefault().AccdId;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                status = -1;
            }
            return status;
        }
        public List<Hotel> GetAllHotels()
        {
            List<Hotel> hotels = new List<Hotel>();
            try
            {
                hotels = (from h in Context.Hotel
                          select h).ToList();
            }
            catch (Exception)
            {

                hotels = null;
            }
            return hotels;
        }
        public int AddVehicle(Vehicle vehicle)
        {
            int vehicleId;
            try
            {
                Context.Vehicle.Add(vehicle);
                Context.SaveChanges();
                vehicleId = (from v in Context.Vehicle
                             where v.VehicleName == vehicle.VehicleName
                             select v.Vid).FirstOrDefault();
            }
            catch (Exception)
            {

                vehicleId = -1;
            }
            return vehicleId;
        }
        public List<Vehicle> GetAllVehicles()
        {
            List<Vehicle> vehicles = new List<Vehicle>();
            try
            {
                vehicles = (from v in Context.Vehicle
                            select v).ToList();
            }
            catch (Exception)
            {

                vehicles = null;
            }
            return vehicles;
        }
        ///////////////////////RATHEESH CODE END/////////////////////////////////////

        /////////////////SPRINT 2//////////////////////////
        public string RegisterQuery(string question, int bookingId)
        {
            string status;
            try
            {
                var emp = (from user in Context.Employee select user.EmpId).ToList();
                int[] eId = emp.ToArray();

                Random rand = new Random();
                int index = rand.Next(eId.Length);
                Employee assignee = new Employee
                {
                    EmpId = eId[index]
                };
                assignee = Context.Employee.Find(assignee.EmpId);
                CustomerCare cc = new CustomerCare
                {
                    BookingId = bookingId,
                    Assignee = assignee.FirstName,
                    Query = question,
                    QueryStatus = "Assigned"
                };
                Context.CustomerCare.Add(cc);
                Context.SaveChanges();
                status = "query registered";
            }
            catch (Exception)
            {
                status = "Could not register query.";
            }
            return status;
        }
        
        public string AnsQuery(string ans, int qId)
        {
            string status;
            try
            {
                CustomerCare cc = new CustomerCare();
                cc.QueryId = qId;
                cc = Context.CustomerCare.Find(cc.QueryId);
                cc.QueryAns = ans;
                cc.QueryStatus = "In Progress";
                Context.CustomerCare.Update(cc);
                Context.SaveChanges();
                status = "Query Answered!";
            }
            catch(Exception)
            {
                status = "Unable to submit your answer!";
            }
            return status;

        }

        public int AddHotels(Hotel hotel)
        {
            int status = 0;
            try
            {
                Context.Hotel.Add(hotel);
                Context.SaveChanges();
                int item = (from h in Context.Hotel
                            where h.PackageId == hotel.PackageId
                            select h.Hid).FirstOrDefault();
                status = item;
            }
            catch (Exception)
            {
                status = -1;
            }
            return status;
        }

        public int AddPackage(Package pack)
        {
            int status = 0;
            try
            {
                Context.Package.Add(pack);
                Context.SaveChanges();
                int item = (from h in Context.Package
                            where h.PackageName == pack.PackageName
                            select h.PackageId).FirstOrDefault();
                status = item;
            }
            catch (Exception)
            {
                status = -1;
            }
            return status;
        }

      public List<Customer> CustomerByEmailId(string email)
        {
            List<Customer> cc = new List<Customer>();
            try
            {
                cc = (from bk in Context.Customer where bk.EmailId == email select bk).ToList();

            }
            catch (Exception)
            {
                cc = null;
            }
            return cc;
        }
        public List<CustomerCare> EmpGetQueries(string email)
        {
            List<CustomerCare> cc = new List<CustomerCare>();
            try
            {
                var b = (from bk in Context.Employee where bk.EmailId == email select bk.FirstName).ToList();

                foreach (var bb in b)
                    cc = (from qq in Context.CustomerCare where qq.Assignee == bb && qq.QueryStatus != ("Closed") select qq).ToList();
            }
            catch (Exception)
            {
                cc = null;
            }
            return cc;
        }
        public List<CustomerCare> GetQueries(string email)
        {
            List<CustomerCare> cc = new List<CustomerCare>();
            try
            {
            var b = (from bk in Context.Booking where bk.EmailId == email select bk.BookingId).ToList();
            
            foreach (var bb in b) 
               cc = (from qq in Context.CustomerCare where qq.BookingId == bb && qq.QueryStatus!=("Closed") select qq).ToList();
            }
            catch (Exception)
            {
                cc = null;
            }
            return cc;
        }
        public bool Close(int qId)
        {
            bool status;
            CustomerCare cc = new CustomerCare();
            cc.QueryId = qId;
            try
            {
                cc = Context.CustomerCare.Find(cc.QueryId);
                cc.QueryStatus = "Closed";
                Context.CustomerCare.Update(cc);
                Context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
    }

}
