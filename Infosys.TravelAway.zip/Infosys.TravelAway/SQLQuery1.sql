﻿Create database TravelAway
GO
USE TravelAway
GO

create table Roles(
[RoleId] TINYINT CONSTRAINT pk_RoleId PRIMARY KEY IDENTITY,
[RoleName] VARCHAR(20) CONSTRAINT uq_RoleName UNIQUE
);

SET IDENTITY_INSERT Roles ON
INSERT INTO Roles(RoleId,RoleName) VALUES (1,'Customer')
INSERT INTO Roles(RoleId,RoleName) VALUES (2,'Employee')
SET IDENTITY_INSERT Roles OFF
GO

CREATE TABLE Customer(
[EmailId] VARCHAR(30) CONSTRAINT pk_EmailId PRIMARY KEY,
[RoleId] TINYINT CONSTRAINT fk_RoleId REFERENCES Roles(RoleId),
[FirstName] VARCHAR(20) CONSTRAINT chk_FirstName CHECK(NOT [FirstName] LIKE '% %') NOT NULL,
[LastName] VARCHAR(20) CONSTRAINT chk_LastName CHECK(NOT [LastName] LIKE '% %') NOT NULL,
[Password] VARCHAR(16) CONSTRAINT chk_Password CHECK(len([Password])>=8 AND len([Password])<=16) NOT NULL,
[Gender] CHAR CONSTRAINT chk_Gender CHECK(Gender in('F', 'M')) NOT NULL,
[ContactNo] NUMERIC(10) CONSTRAINT chk_ContactNo check([ContactNo] NOT LIKE '0%' AND len([ContactNo])=10) NOT NULL, --SQUARE BRACES
[DateOfBirth] DATE CONSTRAINT chk_DateOfBirth CHECK(DateOfBirth<GETDATE()) NOT NULL,
[Address] VARCHAR(350) NOT NULL
);

GO

CREATE TABLE Hotel(
[HId] INT CONSTRAINT pk_HId PRIMARY KEY IDENTITY(1000,1),
[HotelName] VARCHAR(20),
[HotelType] INT NOT NULL CONSTRAINT chk_HotelType CHECK(HotelType>=2 AND HotelType<=5),
[SingleRoomPrice] MONEY,
[DoubleRoomPrice] MONEY,
[DeluxeRoomPrice] MONEY,
[SuiteRoomPrice] MONEY,
[City] VARCHAR(30)
);
GO

CREATE TABLE PackageCategory(
[CategoryId] INT CONSTRAINT pk_CategoryId PRIMARY KEY IDENTITY(100,1),
[CategoryName] VARCHAR(25) UNIQUE NOT NULL
);
GO
CREATE TABLE Package(
[PackageId] INT CONSTRAINT pk_PackageId PRIMARY KEY IDENTITY(2000,1),
[PackageInfo] VARCHAR(100) NOT NULL,
[PackageName] VARCHAR(40) UNIQUE NOT NULL,
[CategoryId] INT CONSTRAINT fk_CategoryId REFERENCES PackageCategory(CategoryId),
[PackageType] VARCHAR(20) CONSTRAINT chk_PackageType CHECK(PackageType IN ('International','Domestic'))
);
GO


CREATE TABLE PackageDetails(
[DetailsId] INT CONSTRAINT pk_DetailsId PRIMARY KEY IDENTITY(900,1),
[PackageId] INT CONSTRAINT fk_PackageId REFERENCES Package(PackageId),
[PlacesToVisit] VARCHAR(500) NOT NULL,
[Description] VARCHAR(500) NOT NULL,
[Days] INT NOT NULL,
[Nights] INT NOT NULL,
[Accomodation] VARCHAR(20) CONSTRAINT chk_Accomodation CHECK(Accomodation IN ('Available','Unavailable')),
[PricePerAdult] DECIMAL
);
GO
Alter table Hotel Add [PackageId] INT CONSTRAINT fk_packId_hotels REFERENCES Package(PackageId)
GO
CREATE TABLE Booking(
[EmailId] VARCHAR(30) CONSTRAINT fk_EmailId REFERENCES Customer(EmailId),
[BookingId] INT CONSTRAINT pk_BookingId PRIMARY KEY IDENTITY(10000,1),
[ContactNo] NUMERIC(10) UNIQUE NOT NULL CONSTRAINT chk_BookingContactNo CHECK(ContactNo>999999999 AND ContactNo<=9999999999),
[Address] VARCHAR(100) NOT NULL,
[TravelDate] DATE NOT NULL CONSTRAINT chk_TravelDate CHECK(TravelDate>=GETDATE()),
[NoOfAdults] INT NOT NULL,
[NoOfChildren] INT,
[Status] VARCHAR(15) NOT NULL,
[PackageId] INT CONSTRAINT fk_packId REFERENCES Package(PackageId)
);
GO

CREATE TABLE Accomodation(
[AccdId] INT CONSTRAINT pk_AccdId PRIMARY KEY IDENTITY(1,1),
[BookingId] INT CONSTRAINT fk_BookingId REFERENCES Booking(BookingId),
[HId] INT CONSTRAINT fk_HId REFERENCES Hotel(HId),
[City] VARCHAR(30),
[NoOfRooms] INT NOT NULL,
[Price] MONEY,
[RoomType] VARCHAR(10) CONSTRAINT chk_RoomType CHECK(RoomType='Single' OR RoomType='Double' OR RoomType='Deluxe' OR RoomType='Suite') NOT NULL
);

GO

CREATE TABLE Rating(
[RId] INT CONSTRAINT pk_RId PRIMARY KEY IDENTITY(1,1),
[Review] VARCHAR(200),
[Rating] INT CONSTRAINT chk_Rating CHECK(Rating>0 AND Rating<=5),
[BookingId] INT CONSTRAINT fk_BookId REFERENCES Booking(BookingId)
);
GO



CREATE TABLE Vehicle(
[VId] INT CONSTRAINT pk_VId PRIMARY KEY IDENTITY(500,1),
[VehicleName] VARCHAR(30) NOT NULL,
[VehicleType] VARCHAR(20) CONSTRAINT chk_Vehicle CHECK(VehicleType='Two-Wheeler' OR VehicleType='Four-Wheeler' OR VehicleType='Mini-Bus'),
[RatePerHour] DECIMAL(20,2) NOT NULL,
[RatePerKm] DECIMAL(20,2) NOT NULL,
[BasePrice] DECIMAL(20,2) NOT NULL
);
GO




CREATE TABLE VehicleBooked(
[VehicleBookingId] INT CONSTRAINT pk_VehicleBookingId PRIMARY KEY IDENTITY,
[VId] INT CONSTRAINT fk_VId REFERENCES Vehicle(VId),
[VehicleName] VARCHAR(20) NOT NULL,
[BookingDate] DATE CONSTRAINT chk_BookingDate CHECK(BookingDate>=GETDATE()) NOT NULL,
[PickupTime] VARCHAR(20) NOT NULL,
[NoOfHours] INT CONSTRAINT chk_NoOfHours CHECK([NoOfHours]>=3) NOT NULL,
[NoOfKms] INT NOT NULL,
[TotalCost] DECIMAL(20,2) NOT NULL,
[VehicleStatus] VARCHAR(30) CONSTRAINT chk_status CHECK (VehicleStatus='Booked' OR VehicleStatus='Active' OR VehicleStatus='Closed')
)
GO

CREATE TABLE Employee(
[EmpId] INT CONSTRAINT pk_EMPID PRIMARY KEY IDENTITY,
[FirstName] VARCHAR(50) CONSTRAINT chk_FName CHECK(NOT[FirstName] LIKE '% %') NOT NULL,
[LastName] VARCHAR(50) CONSTRAINT chk_LName CHECK(NOT[LastName] LIKE '% %') NOT NULL,
[Password] VARCHAR(15) CONSTRAINT chk_EmployeePassword CHECK(len([Password])>=8 AND LEN ([Password])<=16) NOT NULL,
[RoleId] TINYINT CONSTRAINT fk_RId REFERENCES Roles(RoleId),
[EmailId] VARCHAR(50)
)
GO



CREATE TABLE CustomerCare(
[QueryId] INT CONSTRAINT pk_QueryId PRIMARY KEY IDENTITY,
[BookingId] INT CONSTRAINT fk_BId REFERENCES Booking(BookingId),
[Query] VARCHAR(100),
[QueryStatus] VARCHAR(30) CONSTRAINT chk_QueryStatus CHECK(QueryStatus='Assigned' OR QueryStatus='In Progress' OR QueryStatus='Closed'),
[Assignee] VARCHAR(50),
[QueryAns] VARCHAR(200)
)
GO

CREATE TABLE Payment(
[PaymentId] INT CONSTRAINT pk_PaymentId PRIMARY KEY IDENTITY,
[BookingId] INT CONSTRAINT fk_PaymentBookId REFERENCES Booking(BookingId),
[TotalAmount] MONEY,
[PaymentStatus] VARCHAR(20) CONSTRAINT chk_PaymentStatus CHECK (PaymentStatus='Confirmed' OR PaymentStatus='Not Confirmed')
);
GO



CREATE PROCEDURE usp_RegisterCustomer
(
@EmailId VARCHAR(30),
@FirstName VARCHAR(20),
@LastName VARCHAR(20),
@Password VARCHAR(16),
@Gender CHAR,
@Contact NUMERIC(10),
@DOB DATE,
@Address VARCHAR(50)
)
AS BEGIN
	DECLARE @RoleId CHAR(2),
		@retval INT
	BEGIN TRY
		IF(LEN(@EmailId)<4 OR LEN(@EmailId) IS NULL OR @EmailId NOT LIKE ('_%@_%.com'))
		SET @retval=-1
		ELSE IF(LEN(@Password)<8 OR LEN(@Password)>16 OR (@Password IS NULL))
		SET @retval=-2
		ELSE IF(@DOB>=CAST(GETDATE() AS DATE) OR (@DOB IS NULL))
		SET @retval=-3
		ELSE IF (DATEDIFF(day,@DOB,GETDATE())<6570)
		SET @retval=-4
		ELSE IF(@FirstName LIKE('%[^a-zA-Z]%') OR LEN(@FirstName)=0)
		SET @retval=-5
		ELSE IF(@LastName LIKE ('%[^a-zA-Z]%') OR LEN(@LastName)=0)
		SET @retval=-5
		ELSE
			BEGIN
				SELECT @RoleId=RoleId FROM dbo.Roles WHERE RoleName='Customer'
				INSERT INTO dbo.Customer VALUES
				(@EmailId,@RoleId,@FirstName,@LastName,@Password,@Gender,@Contact,@DOB,@Address)
				SET @retval=1
			END
		SELECT @retval
	END TRY
	BEGIN CATCH
		SET @retval=-99
		SELECT @retval, ERROR_LINE(),ERROR_MESSAGE()
	END CATCH
END 

GO





CREATE FUNCTION ufn_ViewAllPackages()
RETURNS TABLE
AS
	RETURN (SELECT P.PackageId,P.CategoryId,P.PackageName,P.PackageInfo,P.PackageType 
	FROM Package P JOIN PackageDetails PD ON P.PackageId=PD.PackageId)
go

CREATE FUNCTION ufn_ViewPackageCategory(@PackageCategoryName VARCHAR(20))
RETURNS TABLE
AS 
RETURN
	(SELECT P.PackageName,PD.[Description] FROM Package P JOIN PackageDetails PD ON P.PackageId=PD.PackageID 
	WHERE P.CategoryId IN (SELECT CategoryId FROM PackageCategory WHERE CategoryName=@PackageCategoryName))

Go





CREATE PROCEDURE [usp_AddAccommodation]
(
@BookingId INT,
@City VARCHAR(20),
@Hid INT,
@RoomType VARCHAR(20),
@NoOfRooms INT,
@EstimatedCost NUMERIC
)
AS
BEGIN
	BEGIN TRY
		IF NOT EXISTS (SELECT BookingId FROM Booking WHERE BookingId=@BookingId)
		BEGIN
			RETURN -1;
		END
		ELSE IF NOT EXISTS (SELECT HotelName FROM Hotel WHERE HId=@Hid)
		BEGIN
			RETURN -2;
		END
		ELSE
		BEGIN
			INSERT INTO dbo.[Accomodation](BookingId,City,Hid,RoomType,NoOfRooms,Price)
			VALUES(@BookingId,@City,@Hid,@RoomType,@NoOfRooms,@EstimatedCost)
			RETURN 1;
		END
	END TRY

	BEGIN CATCH
		RETURN -99
	END CATCH
	
	
	
END
GO







CREATE FUNCTION ufn_GetAccommodationByBookingId(@BookingId INT)
RETURNS TABLE
AS
RETURN (SELECT * FROM Accomodation WHERE BookingId=@BookingId)

GO




CREATE PROCEDURE usp_bookingCost(@BookingId INT)  
AS

BEGIN
	DECLARE @COST DECIMAL
	SET @COST=(SELECT ((pd.PricePerAdult*(pd.[Days]+pd.Nights))+(pd.PricePerAdult*bp.NoOfAdults)+(pd.PricePerAdult*bp.NoOfChildren/2))
    FROM PackageDetails pd JOIN Booking bp on pd.PackageId = bp.PackageId WHERE bp.BookingId = @BookingId)
	RETURN @COST
END

GO




CREATE FUNCTION ufn_GetBookings(@EmailId VARCHAR(50))
RETURNS TABLE
AS
RETURN SELECT bp.BookingId, bp.EmailId, p.PackageName, p.PackageType, bp.TravelDate,bp.NoOfAdults, bp.NoOfChildren
FROM Package p JOIN Booking bp ON p.PackageId = bp.PackageId WHERE bp.EmailId = @EmailId

GO




CREATE FUNCTION ufn_GetReportByPackageName()
RETURNS TABLE 
AS
RETURN (SELECT p.PackageName AS PackageName, COUNT(p.PackageName) AS Bookings FROM Package p
INNER JOIN Booking b ON b.PackageId=p.PackageId GROUP BY PackageName)

GO




CREATE FUNCTION ufn_GetReportByPackageCategoryName()
RETURNS TABLE
AS
RETURN(SELECT pc.CategoryName, COUNT(p.CategoryId) AS AvailablePackage FROM PackageCategory pc
INNER JOIN Package p on p.CategoryId=pc.CategoryId GROUP BY pc.CategoryName)

Go




CREATE FUNCTION ufn_GetReportByMonth(@month INT)
RETURNS TABLE 
AS
RETURN(
SELECT pd.DetailsId,COUNT(b.PackageId) AS NumberOfBookings
FROM PackageDetails pd INNER JOIN Booking b ON
pd.PackageId=b.PackageId WHERE MONTH(b.TravelDate)=@month
GROUP BY pd.DetailsId
)
GO








CREATE PROCEDURE usp_AddAnswer
(
@QueryId INT, @QueryStatus VARCHAR(30), @Answer VARCHAR(100)
)
AS 
BEGIN
BEGIN TRY
IF(@QueryId IS NULL)
RETURN -1
IF(@QueryStatus IS NULL)
RETURN -2
IF(@Answer IS NULL)
RETURN -3
ELSE
BEGIN
UPDATE CustomerCare SET QueryStatus=@QueryStatus, QueryAns=@Answer
WHERE QueryId=@QueryId 
RETURN 1
END
END TRY
BEGIN CATCH
RETURN -98
END CATCH
END

GO












CREATE PROCEDURE usp_CloseQuery
(
@QueryId INT,@QueryStatus VARCHAR(30)
)
AS
BEGIN
BEGIN TRY
IF(@QueryId IS NULL)
RETURN -1
IF(@QueryStatus IS NULL)
RETURN -2
ELSE
BEGIN
UPDATE CustomerCare SET QueryStatus=@QueryStatus
WHERE QueryId=@QueryId
RETURN 1
END
END TRY
BEGIN CATCH
RETURN -99
END CATCH
END

GO
create function ufn_GetRoleIdByCredentials(@EmailId varchar(30), @Password varchar(16)) 
Returns INT
AS
BEGIN
    DECLARE @RoleId INT
    SET @RoleId = 0
	      IF EXISTS(SELECT RoleId FROM Employee WHERE EmailId=@EmailId AND [Password]=@Password)
          SET @RoleId=2
          ELSE IF EXISTS (SELECT RoleId FROM Customer WHERE EmailId=@EmailId AND [Password]=@Password)
          SET @RoleId=1
		  ELSE
		  SET @RoleId=0

RETURN @RoleId
END

GO



INSERT INTO Customer(EmailId,Password,RoleId,Gender,FirstName,LastName,ContactNo,DateOfBirth,[Address]) VALUES('customer.one@gmail.com','custone@123',1,'F','Customer','One',9876543210,'2000-01-01','USA');
INSERT INTO Customer(EmailId,Password,RoleId,Gender,FirstName,LastName,ContactNo,DateOfBirth,[Address]) VALUES('customer.two@gmail.com','custtwo@123',1,'M','Customer','Two',8050558601,'1998-10-26','#25, Bangalore');
INSERT INTO Customer(EmailId,Password,RoleId,Gender,FirstName,LastName,ContactNo,DateOfBirth,[Address]) VALUES('customer.three@gmail.com','custthree123',1,'M','Customer','Three',1234567890,'1998-09-23','Birmingham');
INSERT INTO Customer(EmailId,Password,RoleId,Gender,FirstName,LastName,ContactNo,DateOfBirth,[Address]) VALUES('customer.four@gmail.com','custfour@123',1,'F','Customer','Four',9598675432,'1999-04-01','#52, Mangalore');
INSERT INTO Customer(EmailId,Password,RoleId,Gender,FirstName,LastName,ContactNo,DateOfBirth,[Address]) VALUES('customer.five@gmail.com','custfive@123',1,'F','Customer','Five',9876543210,'2000-01-01','USA');

GO

INSERT INTO Employee(FirstName,LastName,Password,RoleId,EmailId) VALUES('Admin','Main','admin@123',2,'admin@travelaway.com');
INSERT INTO Employee(FirstName,LastName,Password,RoleId,EmailId) VALUES('Ratheesh','MR','ratheesh@123',2,'ratheesh.r04@travelaway.com');
INSERT INTO Employee(FirstName,LastName,Password,RoleId,EmailId) VALUES('Himanshu','Sharma','himanshu@123',2,'himanshu.sharma47@travelaway.com');
INSERT INTO Employee(FirstName,LastName,Password,RoleId,EmailId) VALUES('Pavithra','S','pavithra@123',2,'pavithra.s61@travelaway.com');
INSERT INTO Employee(FirstName,LastName,Password,RoleId,EmailId) VALUES('Krishna','Singh','krishna@123',2,'krishna.singh04@travelaway.com');
GO

INSERT INTO PackageCategory(CategoryName) VALUES
('Adventure'),
('Nature'),
('Relegious'),
('Village'),
('Wildlife')

GO


SET IDENTITY_INSERT Package OFF
INSERT INTO Package(PackageName,PackageInfo,CategoryId,PackageType) VALUES('Andaman And Nicobar','Visit A&N Islands',100,'International')
INSERT INTO Package(PackageName,PackageInfo,CategoryId,PackageType) VALUES('North East India','Visit NE India',101,'Domestic')
INSERT INTO Package(PackageName,PackageInfo,CategoryId,PackageType) VALUES('Europe','Famous places in Europe',102,'International')
INSERT INTO Package(PackageName,PackageInfo,CategoryId,PackageType) VALUES('North India','Visit NI',103,'Domestic')
INSERT INTO Package(PackageName,PackageInfo,CategoryId,PackageType) VALUES('USA','Visit places in USA',104,'International')
INSERT INTO Package(PackageName,PackageInfo,CategoryId,PackageType) VALUES('Australia','Visit Australia',103,'International')
INSERT INTO Package(PackageName,PackageInfo,CategoryId,PackageType) VALUES('South India','Visit South India',100,'Domestic')
GO

INSERT INTO PackageDetails(PackageId,PlacesToVisit,Description,Days,Nights,Accomodation,PricePerAdult) VALUES(2000,'Port Blair','Complete Trip of PortBlair',3,4,'Unavailable',10000)
INSERT INTO PackageDetails(PackageId,PlacesToVisit,Description,Days,Nights,Accomodation,PricePerAdult) VALUES(2001,'Assam,Sikkim','Complete Trip of North East',5,6,'Available',12000)
INSERT INTO PackageDetails(PackageId,PlacesToVisit,Description,Days,Nights,Accomodation,PricePerAdult) VALUES(2002,'Paris, Amsterdam, Rome, Venice','Sightseeing in Europe',15,16,'Available',500000)
INSERT INTO PackageDetails(PackageId,PlacesToVisit,Description,Days,Nights,Accomodation,PricePerAdult) VALUES(2003,'Haridwar,Rishikesh, Dharamshala, Shimla','Complete trip of the snowy parts of North India',5,6,'Unavailable',30000)
INSERT INTO PackageDetails(PackageId,PlacesToVisit,Description,Days,Nights,Accomodation,PricePerAdult) VALUES(2004,'New York CIty, Manhattan, Queens, San Francisco','All famous destinations in USA',14,15,'Available',1500000)
INSERT INTO PackageDetails(PackageId,PlacesToVisit,Description,Days,Nights,Accomodation,PricePerAdult) VALUES(2005,'Opera House, Melbourne Stadium, Brisbane, The Great Barrier Reef','All famous tourist Hotspots',10,11,'Available',700000)
INSERT INTO PackageDetails(PackageId,PlacesToVisit,Description,Days,Nights,Accomodation,PricePerAdult) VALUES(2006,'Aleppy Backwaters, Kanyakumari, Rameshwaram, Hampi','Popular tourist destinations in South India',15,16,'Unavailable',75000)
GO

SET IDENTITY_INSERT Hotel ON
INSERT INTO Hotel(HId,HotelName,HotelType,SingleRoomPrice,DoubleRoomPrice,DeluxeRoomPrice,SuiteRoomPrice,City,PackageId) VALUES(1000,'The Taj',5,15000,20000,35000,50000,'Alappuzha',2006)
INSERT INTO Hotel(HId,HotelName,HotelType,SingleRoomPrice,DoubleRoomPrice,DeluxeRoomPrice,SuiteRoomPrice,City,PackageId) VALUES(1001,'Sea Shell',3,5800,8500,15000,25000,'Port Blair',2000)
INSERT INTO Hotel(HId,HotelName,HotelType,SingleRoomPrice,DoubleRoomPrice,DeluxeRoomPrice,SuiteRoomPrice,City,PackageId) VALUES(1002,'Manali Express',2,1000,1500,2000,7000,'Manali',2001)
INSERT INTO Hotel(HId,HotelName,HotelType,SingleRoomPrice,DoubleRoomPrice,DeluxeRoomPrice,SuiteRoomPrice,City,PackageId) VALUES(1003,'Clarks Inn',5,1000,15000,25000,45000,'Paris',2002)
GO

SET IDENTITY_INSERT Package OFF
INSERT INTO BOOKING (EmailId,ContactNo,Address,TravelDate,NoOfAdults,NoOfChildren,Status,PackageId) VALUES('customer.one@gmail.com',8050558601, 'London', '2021-10-05', 2,0,'Booked','2000');
INSERT INTO BOOKING (EmailId,ContactNo,Address,TravelDate,NoOfAdults,NoOfChildren,Status,PackageId) VALUES('customer.two@gmail.com',1234567890, 'Birmingham', '2021-08-15', 2,3,'Booked','2001');
INSERT INTO BOOKING (EmailId,ContactNo,Address,TravelDate,NoOfAdults,NoOfChildren,Status,PackageId) VALUES('customer.three@gmail.com',8050588601, 'London', '2021-11-05', 4,2,'Booked','2000');
INSERT INTO BOOKING (EmailId,ContactNo,Address,TravelDate,NoOfAdults,NoOfChildren,Status,PackageId) VALUES('customer.four@gmail.com',9547814587, 'Birmingham', '2021-12-15', 2,4,'Booked','2002');
Go




