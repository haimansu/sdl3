﻿using System;
//using Infosys.TravelAway.DataAccessLayer;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Infosys.TravelAway.DataAccessLayer;
using Infosys.TravelAway.DataAccessLayer.Models;

namespace Infosys.TravelAway.ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //TestRegistration();
            //TestLogin();
            TravelAwayRepository repos = new TravelAwayRepository();
          
            repos.GetQueries("customer.one@gmail.com");
            //foreach(var b in book)
            //{
            //    Console.WriteLine(b.BookingId);
            //}
            //string ans = repos.AnsQuery("No Sir, there is no extra charge!", 5);
            //Console.WriteLine(ans);
            //string status = repos.RegisterQuery("is theres an extra charge for a local guide?", 10000);
            //Console.WriteLine(status);
            //var package = repos.GetAllPackagesusingTVF();
            //foreach(var p in package)
            //{
            //    Console.WriteLine(p.PackageId);
            //    Console.WriteLine(p.PackageInfo);
            //}

            //var pack = repos.GetAllPackageCategories();
            //foreach(var cat in pack)
            //{
            //    Console.WriteLine(cat.CategoryId);
            //    Console.WriteLine(cat.CategoryName);
            //}


            //string catName = "Nature";
            //var lstpackages = repos.GetPackageByCategoryName(catName);
            //if (lstpackages.Count == 0)
            //{
            //    Console.WriteLine("No packages available under the category = " + catName);
            //}
            //else
            //{
            //    Console.WriteLine("{0,-15}{1,-30}{2,-15}", "PackageId", "PackageName", "Description");
            //    Console.WriteLine("---------------------------------------------------------------------------------------");
            //    foreach (var product in lstpackages)
            //    {
            //        Console.WriteLine("{0,-15}{1,-30}{2,-15}", product.PackageId, product.PackageName, product.PackageInfo);
            //    }
            //}


            //string packName = "USA";
            //var lstpackages = repos.GetAllPackageDetails(packName);
            //if (lstpackages.Count == 0)
            //{
            //    Console.WriteLine("No packages available under the category = " + packName);
            //}
            //else
            //{
            //    Console.WriteLine("{0,-15}{1,-50}{2,-15}", "PackageId", "PlacesToVisit", "Description");
            //    Console.WriteLine("---------------------------------------------------------------------------------------");
            //    foreach (var product in lstpackages)
            //    {
            //        Console.WriteLine("{0,-15}{1,-50}{2,-15}", product.PackageId, product.PlacesToVisit, product.Description);
            //    }
            //}


        }
        static void TestLogin()
        {
            TravelAwayRepository repos = new TravelAwayRepository();
            string result = repos.Login("ratheesh.r04@travelaway.com", "ratheesh@123");

            if (result.Equals("Employee"))
                Console.WriteLine("Successfully logged in as employee");
            else if (result.Equals("Customer"))
                Console.WriteLine("Successfully logged in as Customer");
            else
                Console.WriteLine(result);

        }

        //static void TestRegistration()
        //{
        //    TravelAwayRepository repos = new TravelAwayRepository();

        //    int result = repos.Registration("heyman1@gmail.com", "hey", "man", "heyman@123", 'M', 8521479630, new DateTime(1995, 12, 30), "heyman 2nd street london UK");


        //    if (result == 1)
        //        Console.WriteLine("Customer Registered!");
        //    else if (result == -1)
        //        Console.WriteLine("Email invalid or empty");
        //    else if (result == -2)
        //        Console.WriteLine("Invalid Password or empty");
        //    else if (result == -3)
        //        Console.WriteLine("Invalid DOB");
        //    else if (result == -4)
        //        Console.WriteLine("Must be 18+ to register");
        //    else if (result == -5)
        //        Console.WriteLine("Name is mandatory or invalid");
        //    else
        //        Console.WriteLine("unable to register");

        //}
    }
}
