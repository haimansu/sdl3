import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';
import { ICustomerCare } from '../travel-away-interfaces/customerCare';
import { TravelawayService } from '../travelAway-services/travelaway.service';

@Component({
  selector: 'app-reply-query',
  templateUrl: './reply-query.component.html',
  styleUrls: ['./reply-query.component.css']
})
export class ReplyQueryComponent implements OnInit {

  msg: string;
  userRole: string;
  customerLayout: boolean = false;
  commonLayout: boolean = false;
  employeeLayout: boolean = false;
  errorMsg: any;
  showMsg: boolean;
  status: string;
  showDiv: boolean = false;
  ccForm: FormGroup;
  queries: ICustomerCare[];

  constructor(private formBuilder: FormBuilder, private _userService: TravelawayService, private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;
  }

  ngOnInit(): void {
    this.ccForm = this.formBuilder.group({
      answer: ['', Validators.required],
      queryId: ['', Validators.required]
    })
  }

  SubmitForm(form: FormGroup) {
    console.log(form.value.answer);

    this._userService.AnswerQuery(form.value.answer, parseInt(form.value.queryId)).subscribe(
      responseQueryStatus => {
        this.status = responseQueryStatus;
        console.log(this.status);
        if (this.status == "Query Answered!") {

          this.msg = "Query Answered!";
          alert(this.msg);
          this.router.navigate(['/assigneeBoard']);
        }
        else {
          this.msg = "Unable to Answer Query.";
          alert(this.msg);
          this.router.navigate(['/assigneeBoard']);
        }
      },
      responseSubmitError => {
        this.errorMsg = responseSubmitError;
        console.log(this.errorMsg);
      },
      () => { console.log("AnswerQuery Method executed successfully"); }
    )
  }
}
