import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplyQueryComponent } from './reply-query.component';

describe('ReplyQueryComponent', () => {
  let component: ReplyQueryComponent;
  let fixture: ComponentFixture<ReplyQueryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReplyQueryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplyQueryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
