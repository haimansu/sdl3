import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookAccomodationComponent } from './book-accomodation.component';

describe('BookAccomodationComponent', () => {
  let component: BookAccomodationComponent;
  let fixture: ComponentFixture<BookAccomodationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookAccomodationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookAccomodationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
