import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { IHotel } from '../travel-away-interfaces/IHotel';
import { TravelawayService } from '../travelAway-services/travelaway.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-book-accomodation',
  templateUrl: './book-accomodation.component.html',
  styleUrls: ['./book-accomodation.component.css']
})
export class BookAccomodationComponent implements OnInit {
  bookAccomodationForm: FormGroup;
  allHotels: IHotel[];
  hotels: IHotel[];
  filteredHotels: IHotel[];
  ratingfilter: IHotel[];
  nameFilter: IHotel[];
  errMsg: string;
  searchByCity: string = "0";
  searchByRating: string = "0";
  searchByHotel: number = 0;
  commonLayout: boolean = false;
  customerLayout: boolean = false;
  employeeLayout: boolean = false;
  userRole: string;
  accId: number;
  estimatedCost: number = 0;
  roomType: string;
  hotelName: string;
  hId: number;
  hotel: IHotel;
  noOfRooms: number = 0;



  constructor(private _travelservice: TravelawayService, private formBuilder: FormBuilder, private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    console.log(this.userRole);
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;
  }

  ngOnInit() {
    if (sessionStorage.getItem('bookingId') == null) {
      alert("You do not have a package booked. Please book a package to select accomodation");
      this.router.navigate(['/viewPackages']);
    }
    else {
      this.getHotels();
      this.bookAccomodationForm = this.formBuilder.group({
        bookingId: [{ value: sessionStorage.getItem('bookingId'), disabled: true }],
        city: ['', Validators.required],
        hotelRating: ['', Validators.required],
        hotelName: ['', Validators.required],
        roomType: ['', Validators.required],
        noOfRooms: ['', Validators.required],
        estimateCost: [{ disabled: true }]
      })
    }

  }
  getHotels() {
    this._travelservice.getHotels().subscribe(
      responseHotelData => {
        this.hotels = responseHotelData;
        this.allHotels = this.hotels;
        console.log(this.allHotels);
        this.filteredHotels = responseHotelData;
        //this.showMsgDiv = false;
      },
      responseHotelError => {
        this.hotels = null;
        this.errMsg = responseHotelError;
        console.log(this.errMsg);
      },
      () => { console.log("GetHotels method executed") }
    );
  }



  filterByCity(city: string) {
    this.filteredHotels = this.hotels;
    this.searchByCity = city;
    if (this.searchByCity == "0")
      this.filteredHotels = this.hotels;
    //else if (this.searchByRating == "0" && this.searchByHotel == "0")
    //  this.hotels = this.allHotels;
    else
      this.filteredHotels = this.filteredHotels.filter(hot => hot.city == this.searchByCity);
    this.ratingfilter = this.filteredHotels;
    this.nameFilter = this.filteredHotels;
    console.log(this.filteredHotels);
    // this.CalculateEstimatedCost();
  }



  filterByRating(rating: string) {
    if (this.ratingfilter == null) {
      this.ratingfilter = this.hotels;
    }

    this.searchByRating = rating;
    if (this.searchByRating == "0")
      this.ratingfilter = this.filteredHotels;
    //else if (this.searchByCity == "0" && this.searchByHotel == "0")
    //  this.hotels = this.allHotels;
    else
      this.ratingfilter = this.filteredHotels.filter(hot => hot.hotelType.toString() == this.searchByRating);
    console.log(this.ratingfilter);
    this.nameFilter = this.ratingfilter;
    console.log(this.ratingfilter);
    // this.CalculateEstimatedCost();
  }



  filterByHotel(name: number): void {
    console.log(name);
    this.hId = name;
    this.hotel = this.allHotels.find(hot => hot.hid == name);
    console.log(this.hotel);
    this.CalculateEstimatedCost();
  }




  SubmitForm(form: FormGroup) {
    console.log(sessionStorage.getItem('userName'), this.searchByCity, this.searchByRating, this.hId, this.noOfRooms, this.roomType);
    //this.roomType = form.value.roomType;
    // this.hotelName = form.value.hotelName;
    // this.CalculateEstimatedCost();
    this._travelservice.BookAccomodation(parseInt(sessionStorage.getItem('bookingId')), this.searchByCity, this.hId, this.noOfRooms, this.roomType).subscribe(
      responseAccomodationStatus => {
        this.accId = responseAccomodationStatus;
        if (this.accId > 0) {
          sessionStorage.setItem('accId', this.accId.toString());
          if (confirm("Accomodation Booking Successful.Do you wish to proceed to payment?"))
            this.router.navigate(['/payment']);
          else
            this.router.navigate(['/bookingHistory']);
        }
        else {
          alert("Please select all the details");
          this.router.navigate(['/bookAccomodation']);
        }
      },
      responseAccomodationError => {
        this.accId = responseAccomodationError;
        alert("Booking unsuccessful please try again");
        this.router.navigate(['/bookAccomodation']);
      },
      () => { console.log("SubmitForm method executed successfully") }
    );


  }
  Reset() {
    this.hotels = this.allHotels;
    this.filteredHotels = this.allHotels;
  }
  CalculateEstimatedCost() {
    if (this.hotel.hid > 0) {
      //this.roomType = this.bookAccomodationForm.value.roomType;
      if (this.roomType == "Single") {
        //for (let hotel of this.allHotels) {
        //  if (this.bookAccomodationForm.value.hotelName == hotel.hotelName) {
        //    this.estimatedCost = hotel.singleRoomPrice * this.bookAccomodationForm.value.noOfRooms;
        //  }
        //}
        // this.hotel = this.allHotels.find(e => e.hid == this.searchByHotel);
        console.log(this.hotel);
        this.estimatedCost = this.hotel.singleRoomPrice * this.bookAccomodationForm.value.noOfRooms;
      }
      else if (this.roomType == "Double") {
        //for (let hotel of this.allHotels) {
        //  if (this.bookAccomodationForm.value.hotelName == hotel.hotelName) {
        //    this.estimatedCost = hotel.doubleRoomPrice * this.bookAccomodationForm.value.noOfRooms;
        //  }
        //}
        //this.hotel = this.allHotels.find(e => e.hid == this.searchByHotel);
        console.log(this.hotel);
        this.estimatedCost = this.hotel.doubleRoomPrice * this.noOfRooms;
      }
      else if (this.roomType == "Deluxe") {
        //for (let hotel of this.allHotels) {
        //  if (this.bookAccomodationForm.value.hotelName == hotel.hotelName) {
        //    this.estimatedCost = hotel.deluxeRoomPrice * this.bookAccomodationForm.value.noOfRooms;
        //  }
        //}
        //this.hotel = this.allHotels.find(e => e.hid == this.searchByHotel);
        console.log(this.hotel);
        this.estimatedCost = this.hotel.deluxeRoomPrice * this.noOfRooms;
      }
      else if (this.roomType == "Suite") {
        //for (let hotel of this.allHotels) {
        //  if (this.bookAccomodationForm.value.hotelName == hotel.hotelName) {
        //    this.estimatedCost = hotel.suiteRoomPrice * this.bookAccomodationForm.value.noOfRooms;
        //  }
        //}
        // this.hotel = this.allHotels.find(e => e.hid == this.searchByHotel);
        console.log(this.hotel);
        this.estimatedCost = this.hotel.suiteRoomPrice * this.noOfRooms;
      }
      else {
        this.estimatedCost = 0;
      }
    }
    else {
      this.estimatedCost = 0;
    }
    sessionStorage.setItem('estimatedCost', this.estimatedCost.toString());
    console.log("calculate estimated cost executed", +this.estimatedCost);
  }
  setRoomType(room: string) {
    this.roomType = room;
    this.CalculateEstimatedCost();
  }
  setRooms(rooms: number) {
    this.noOfRooms = rooms;
    this.CalculateEstimatedCost();
  }
}
