import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { TravelawayService } from '../travelAway-services/travelaway.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-book-package',
  templateUrl: './book-package.component.html',
  styleUrls: ['./book-package.component.css']
})
export class BookPackageComponent implements OnInit {

  bookPackageForm: FormGroup;
  msg: string;
  bookingId: number;
  packageId: number;
  errorMsg: string;
  commonLayout: boolean = false;
  customerLayout: boolean = false;
  employeeLayout: boolean = false;
  userRole: string;
  date;
  packageName: string;
  constructor(private formBuilder: FormBuilder, private _userService: TravelawayService, private router: Router) {
    this.date = new Date().toISOString().slice(0, 10);
    this.packageId = parseInt(sessionStorage.getItem('packageId'));
    this.packageName = sessionStorage.getItem('packageName');
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;
  }

  ngOnInit() {
    this.date = new Date().toISOString().slice(0, 10);
    this.bookPackageForm = this.formBuilder.group({
      contactNumber: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern("[1-9]{1}[0-9]{9}")]],
      residentialAddress: ['', Validators.required],
      dateOfTravel: ['', [Validators.required, checkDate]],
      noOfAdults: ['', Validators.required],
      noOfChildren: ['', Validators.required]
    })
  }
  SubmitForm(form: FormGroup) {
    console.log(form.value.contactNo, form.value.residentialAddress, form.value.dateOfTravel, form.value.noOfAdults, form.value.noOfChildren);
    this._userService.BookPackage(sessionStorage.getItem('userName'), parseInt(form.value.contactNumber), form.value.residentialAddress, form.value.dateOfTravel, form.value.noOfAdults, form.value.noOfChildren).subscribe(
      responseBookingStatus => {
        this.bookingId = responseBookingStatus;
        console.log(this.bookingId);
        if (this.bookingId > 0) {
          this.msg = "Booking Successful";
          sessionStorage.setItem('bookingId', this.bookingId.toString());
          if (confirm("Package has been successfully booked.Do you wish to book accomodation?")) {
            this.router.navigate(['/bookAccomodation']);
          }
          else
            this.router.navigate(['/bookingHistory']);

        }
        else {
          this.msg = "Booking Unsuccessful";
          alert("Package Booking Failed. Please Try again later");
          this.router.navigate(['/bookPackage']);
        }
      },
      responseBookingError => {
        this.errorMsg = responseBookingError;
        console.log(this.errorMsg);
      },
      () => { console.log("SubmitForm Method executed successfully"); }
    )
  }
}

function checkDate(control: FormControl) {
  var currentDate = new Date();
  var givenDate = new Date(control.value)
  //console.log(currentDate);
  //console.log(givenDate);
  if (givenDate > currentDate || givenDate == null) {
    return null
  }
  else {
    return {
      dateError: {
        message: "Please Enter a future date"
      }
    };
  }
}
