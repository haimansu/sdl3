import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssigneeBoardComponent } from './assignee-board.component';

describe('AssigneeBoardComponent', () => {
  let component: AssigneeBoardComponent;
  let fixture: ComponentFixture<AssigneeBoardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssigneeBoardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssigneeBoardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
