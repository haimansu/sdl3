import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';
import { ICustomerCare } from '../travel-away-interfaces/customerCare';
import { TravelawayService } from '../travelAway-services/travelaway.service';

@Component({
  selector: 'app-assignee-board',
  templateUrl: './assignee-board.component.html',
  styleUrls: ['./assignee-board.component.css']
})
export class AssigneeBoardComponent implements OnInit {
  msg: string;
  userRole: string;
  customerLayout: boolean = false;
  commonLayout: boolean = false;
  employeeLayout: boolean = false;
  errorMsg: any;
  showMsg: boolean;
  status: string;
  showDiv: boolean = false;
  queries: ICustomerCare[];

  constructor(private formBuilder: FormBuilder, private _userService: TravelawayService, private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;}

  ngOnInit(): void {
    this.getQueryList();
  }

  getQueryList() {
    this._userService.empGetQueries(sessionStorage.getItem('userName')).subscribe(
      responseGet => {
        this.showMsg = false;
        this.queries = responseGet;
        console.log(this.queries);
      },
      resonseError => {
        this.showMsg = true
        this.queries = null
        this.errorMsg = resonseError
      },
      () => console.log("GetQueries method executed")
    )
  }

  reply()
  {
    this.router.navigate(['/replyQuery']);
  }

}

