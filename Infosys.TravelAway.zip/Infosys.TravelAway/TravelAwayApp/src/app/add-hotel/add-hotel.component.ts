import { Component, OnInit } from '@angular/core';
import { TravelawayService } from '../travelAway-services/travelaway.service';
import { IHotel } from '../travel-away-interfaces/IHotel';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-hotel',
  templateUrl: './add-hotel.component.html',
  styleUrls: ['./add-hotel.component.css']
})
export class AddHotelComponent implements OnInit {

  hotels: IHotel[];
  errMsg: string;
  addHotelForm: FormGroup;
  msg: string;
  hId: number;
  commonLayout: boolean = false;
  customerLayout: boolean = false;
  employeeLayout: boolean = false;
  userRole: string;

  constructor(private packageService: TravelawayService, private formBuilder: FormBuilder, private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;
  }

  ngOnInit(): void {
    this.addHotelForm = this.formBuilder.group({
      hotelName: ['', Validators.required],
      hotelType: ['', Validators.required],
      singleRoomPrice: ['', Validators.required],
      doubleRoomPrice: ['', Validators.required],
      deluxeRoomPrice: ['', Validators.required],
      suiteRoomPrice: ['', Validators.required],
      city: ['', Validators.required],
      packageId: ['', Validators.required]


    })
  }

  SubmitForm(form: FormGroup) {
    console.log(form.value.hotelName, form.value.hotelType, form.value.singleRoomPrice, form.value.doubleRoomPrice, form.value.deluxeRoomPrice, form.value.suiteRoomPrice, form.value.city, form.value.packageId);
    this.packageService.addHotels(form.value.hotelName, parseInt(form.value.hotelType), parseInt(form.value.singleRoomPrice), parseInt(form.value.doubleRoomPrice), parseInt(form.value.deluxeRoomPrice), parseInt(form.value.suiteRoomPrice), form.value.city, parseInt(form.value.packageId))
      .subscribe(
        responseHotelData => {
          //this.message = responseProductData;
          this.hId = responseHotelData;
          if (this.hId > 0) {
            this.msg = "Hotel added successfully";
            sessionStorage.setItem('hId', this.hId.toString());
            alert("Hotel added sucessfully.");
            this.router.navigate(['/viewAllHotels']);
          }
          else {
            this.msg = "Unsuccessful";
            alert("Something went wrong.Please try again later");
            this.router.navigate(['/addHotel']);
          }
        },
        responseHotelError => {
          this.errMsg = responseHotelError,
            console.log(this.errMsg),
            alert("Sorry, something went wrong. Please try again after sometime.")
        },
        () => console.log("AddHotel method executed successfully")
      );
  }

}
