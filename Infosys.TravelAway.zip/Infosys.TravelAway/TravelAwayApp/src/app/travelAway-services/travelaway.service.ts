import { Injectable } from '@angular/core';
import { IPackage } from 'src/app/travel-away-interfaces/packages';
import { IPackageCategory } from 'src/app/travel-away-interfaces/packageCategory';
import { IPackageDetails } from 'src/app/travel-away-interfaces/packageDetails';
import { HttpParams,HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ICustomer } from 'src/app/travel-away-interfaces/customer';
import { IEmployee } from 'src/app/travel-away-interfaces/employee';
import { IRating } from '../travel-away-interfaces/rating';
import { IHotel } from '../travel-away-interfaces/IHotel';
import { ILoginDetails } from '../travel-away-interfaces/Logindetails';
import { IBooking } from '../travel-away-interfaces/booking';
import { ICustomerCare } from '../travel-away-interfaces/customerCare';
import { IVehicle } from '../travel-away-interfaces/vehicle';
import { IAccomodation } from '../travel-away-interfaces/Accomodation';
import { Icu } from '@angular/compiler/src/render3/r3_ast';

@Injectable({
  providedIn: 'root'
})
export class TravelawayService {

  packages: IPackage;
  categories: IPackageCategory;

  constructor(private http: HttpClient) { }

  getPackages(): Observable<IPackage[]> {
    let tempVar = this.http.get<IPackage[]>('https://localhost:44394/api/User/GetAllPackages').pipe(catchError(this.errorHandler));
    return tempVar;
  }
  getPackageById(packageId: number): Observable<IPackage> {
    let params = new HttpParams();
    params = params.append("packageId", packageId.toString());
    let tempVar = this.http.get<IPackage>('https://localhost:44394/api/User/GetAllPackages', { params: params }).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  getPackageCategories(): Observable<IPackageCategory[]> {
    let tempVar = this.http.get<IPackageCategory[]>('https://localhost:44394/api/User/GetAllPackageCategory').pipe(catchError(this.errorHandler));
    return tempVar;
  }

  getPackageDetails(packName:string): Observable<IPackageDetails[]> {
    //var catObj: IPackageCategory;
    //catObj = { categoryName: catName, categoryId: null };
    let params = new HttpParams();
    params = params.append("packageName", packName);
    let tempVar = this.http.get<IPackageDetails[]>('https://localhost:44394/api/User/GetPackageDetails', { params: params }).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  validateCredentials(id: string, password: string/*, loginRole:number*/): Observable<string> {
    let temp;

    var custObj: ILoginDetails;
    custObj = { emailId:id,password:password }
    temp = this.http.post<number>('https://localhost:44394/api/User/ValidateLogin',custObj).pipe(catchError(this.errorHandler));

    return temp;
  }

  addUserDetails(role: number, firstName: string, lastName: string, email: string, Password: string, gen: string, dateofbirth: Date, contact: number, address: string): Observable<number> {
    var userObj: ICustomer;
    userObj = { firstName: firstName, lastName: lastName, emailId: email, password: Password, roleId: role, gender: gen, dateOfBirth: dateofbirth, contactNo: contact, address: address };
    return this.http.post<number>('https://localhost:44394/api/User/AddRegistration', userObj).pipe(catchError(this.errorHandler));
  }

  editProfile(cust: ICustomer): Observable<boolean> {
    var obj: ICustomer;
    obj = { emailId:sessionStorage.getItem('userName'), roleId:1, firstName: cust.firstName, lastName: cust.lastName, gender: cust.gender, password: cust.password, dateOfBirth: cust.dateOfBirth, address: cust.address, contactNo: cust.contactNo }
    var tempVar = this.http.put<boolean>('https://localhost:44394/api/User/EditProfile',obj).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  //addRating(review1: string, rating1: number, bookingId1: number): Observable<boolean> {
  //  var objUser: IRating;
  //  objUser = { review: review1, rating: rating1, bookingId: bookingId1 };
  //  return this.http.post<boolean>('https://localhost:44394/api/User/EditProfile', objUser).pipe(catchError(this.errorHandler));
  //}

  getHotels(): Observable<IHotel[]> {
    let tempVar = this.http.get<IHotel[]>('https://localhost:44394/api/User/GetAllHotels').pipe(catchError(this.errorHandler));
    return tempVar;
  }

  addHotels(hotelName: string, hotelType: number, singleRoom: number, doubleRoom: number, deluxeRoom: number, suiteRoom: number, city: string, packageId: number): Observable<number> {
    var hotels: IHotel;
    hotels = { hotelName: hotelName, hotelType: hotelType, singleRoomPrice: singleRoom, doubleRoomPrice: doubleRoom, deluxeRoomPrice: deluxeRoom, suiteRoomPrice: suiteRoom, city: city, packageId: packageId };
    return this.http.post<number>('https://localhost:44394/api/User/AddHotels', hotels).pipe(catchError(this.errorHandler));
  }

  BookPackage(emailId: string, contactNo: number, address: string, dateOfTravel: Date, adults: number, children: number): Observable<number> {
    var newBooking: IBooking;
    newBooking = { emailId: emailId, contactNo: contactNo, address: address, travelDate: dateOfTravel, noOfAdults: adults, noOfChildren: children, packageId: parseInt(sessionStorage.getItem('packageId')), status: "Booked" };
    let tempVar = this.http.post<number>('https://localhost:44394/api/User/BookPackage', newBooking).pipe(catchError(this.errorHandler));
    return tempVar;
  }
  BookAccomodation(bookingId: number, city: string, hId: number, rooms: number, roomType: string): Observable<number> {
    var newAcc: IAccomodation;
    newAcc = { bookingId: bookingId, city: city, roomType: roomType, noOfRooms: rooms, hId: hId };
    let tempVar = this.http.post<number>('https://localhost:44394/api/User/BookAccomodation', newAcc).pipe(catchError(this.errorHandler));
    return tempVar;
  }

  BookingHistory(): Observable<IBooking[]> {
    var bookings: IBooking[];
    let params = new HttpParams();
    params = params.append("emailId", sessionStorage.getItem('userName'));
    let tempVar = this.http.get<IBooking[]>('https://localhost:44394/api/User/BookingHistory', { params: params }).pipe(catchError(this.errorHandler));
    return tempVar;
  }
//EmailByBId(bookId: number): Observable<any> {
//    //var newBooking: IBooking;
//    //newBooking = { BookingId: bookId, EmailId: null, ContactNo: null, Address: null, TravelDate: null, NoOfAdults: null, NoOfChildren: null, PackageId: null, Status: null };
//    return this.http.get<string>('https://localhost:44394/api/User/EmailByBId?bId=${bookId}').pipe(catchError(this.errorHandler));
    
  //  }
  //getCustomerQueries(): Observable<ICustomerCare[]> {
  //  return this.http.get<ICustomerCare[]>('https://localhost:44394/api/User/GetQueries').pipe(catchError(this.errorHandler));
  //}

  RegisterQuery(question: string, bookId: number): Observable<string> {
    var newQuery: ICustomerCare;

    //var email = this.http.get<string>('https://localhost:44394/api/User/EmailByBId?bId=bookId').pipe(catchError(this.errorHandler));
    //var email1 = email.toString();
    //var emailId = sessionStorage.getItem('userName');
    //if (email1 == emailId) {
      newQuery = {bookingId: bookId, query: question, queryAns: null, assignee: null };
      return this.http.post<string>('https://localhost:44394/api/User/RegisterQuery', newQuery).pipe(catchError(this.errorHandler));
    //}
    //else
    //  return email;
  }

  empGetQueries(emailId:string): Observable<ICustomerCare[]> {
    let params = new HttpParams();
    params = params.append("email", emailId);
    let tempVar = this.http.get<ICustomerCare[]>('https://localhost:44394/api/User/EmpGetQueries', { params: params }).pipe(catchError(this.errorHandler));
    return tempVar;
  }
  closeQuery(qId: number): Observable<boolean> {
    var cQuery:ICustomerCare;
    cQuery = { queryId: qId, bookingId: null, query: null, queryAns: null, assignee: null, queryStatus: null };
    return this.http.put<boolean>('https://localhost:44394/api/User/Close', cQuery).pipe(catchError(this.errorHandler));
  }
  getCustomerByEmail(emailid: string): Observable<ICustomer> {
    let params = new HttpParams();
    params = params.append("email", emailid);
    return this.http.get<ICustomer>('https://localhost:44394/api/User/CustomerByEmailId', { params: params }).pipe(catchError(this.errorHandler));

  }
  AnswerQuery(ans: string, qId: number): Observable<string> {
    var aquery: ICustomerCare;
    aquery = { queryId: qId, bookingId: null, query: null, queryAns: ans, assignee: null, queryStatus: 'Closed' };
    return this.http.put < string > ('https://localhost:44394/api/User/AnsQuery', aquery).pipe(catchError(this.errorHandler));
  }

  getQueries(): Observable<ICustomerCare[]> {
    let params = new HttpParams();
    params = params.append("email", sessionStorage.getItem('userName'));
    let tempVar = this.http.get<ICustomerCare[]>('https://localhost:44394/api/User/GetQueries', { params: params }).pipe(catchError(this.errorHandler));
    return tempVar;
  }

    addVehicle(vName: string, vType: string, ratePerHour: number, ratePerKm: number, basePrice: number): Observable<number> {
    var vehicle: IVehicle;
    vehicle = { vehicleName: vName, vehicleType: vType, ratePerHour: ratePerHour, ratePerKm: ratePerKm, basePrice: basePrice };
    let tempVar = this.http.post<number>('https://localhost:44394/api/User/AddVehicle', vehicle).pipe(catchError(this.errorHandler));
    return tempVar;
  }
  addPackages(pName: string, pInfo: string, pType: string, cId: number): Observable<number> {
    var pack: IPackage;
    pack = { packageName: pName, packageInfo: pInfo, packageType: pType, categoryId: cId };
    let tempVar = this.http.post<number>('https://localhost:44394/api/User/AddPackage', pack).pipe(catchError(this.errorHandler));
    return tempVar;
  }
  GetAllVehicles(): Observable<IVehicle[]> {
    let tempVar = this.http.get<IVehicle[]>('https://localhost:44394/api/User/GetAllVehicles').pipe(catchError(this.errorHandler));
    return tempVar;
  }
  
  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || "Server Error");
  }

}
