export interface IPackageCategory {
  categoryId: number;
  categoryName: string;

}
