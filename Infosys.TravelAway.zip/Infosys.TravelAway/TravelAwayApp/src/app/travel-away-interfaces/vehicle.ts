export interface IVehicle {
  vId?: number;
  vehicleName: string;
  vehicleType: string;
  ratePerHour: number;
  ratePerKm: number;
  basePrice: number;
}
