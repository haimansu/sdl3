export interface IAccomodation {
  accdId?: number;
  bookingId: number;
  hId: number;
  city: string;
  noOfRooms: number;
  roomType: string;
  price?: number;
}
