export interface IHotel {
  hid?: number;
  hotelName: string;
  hotelType: number;
  singleRoomPrice: number;
  doubleRoomPrice: number;
  deluxeRoomPrice: number;
  suiteRoomPrice: number;
  city: string;
  packageId: number;
}
