export interface IBooking {
  emailId: string;
  bookingId?: number;
  contactNo: number;
  address: string;
  travelDate: Date;
  noOfAdults: number;
  noOfChildren: number;
  status: string;
  packageId: number;
}
