export interface ICustomerCare{
  query: string;
  bookingId: number;
  queryAns: string;
  assignee: string;
  queryStatus?: string;
  queryId?: number;
}