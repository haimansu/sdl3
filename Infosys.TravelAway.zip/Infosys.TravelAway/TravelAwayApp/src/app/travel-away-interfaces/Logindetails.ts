export interface ILoginDetails {
  emailId: string;
  password: string;
}
