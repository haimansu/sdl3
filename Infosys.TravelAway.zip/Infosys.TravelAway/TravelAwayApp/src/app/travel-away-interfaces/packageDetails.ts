export interface IPackageDetails {
  detailsId: number;
  packageId: number;
  placesToVisit: string;
  description: string;
  days: number;
  nights: number;
  accomodation: string;
  pricePerAdult: number;
}
