export interface IRating{
  review: string;
  rating: number;
  bookingId: number;
}
