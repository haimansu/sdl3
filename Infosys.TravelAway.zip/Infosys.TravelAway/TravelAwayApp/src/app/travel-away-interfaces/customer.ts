export interface ICustomer {
  emailId: string;
  password: string;
  firstName: string;
  lastName: string;
  address: string;
  roleId: number;
  gender: string;
  contactNo: number;
  dateOfBirth: Date;
}
