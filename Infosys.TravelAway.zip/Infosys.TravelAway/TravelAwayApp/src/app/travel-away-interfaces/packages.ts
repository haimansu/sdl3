export interface IPackage {
  packageId?: number;
  packageName: string;
  packageType: string;
  packageInfo: string;
  categoryId: number;
  }
