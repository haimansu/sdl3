export interface IEmployee {
  emailId: string;
  password: string;
  roleId: 1;
}
