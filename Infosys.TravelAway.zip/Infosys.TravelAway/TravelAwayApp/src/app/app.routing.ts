import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from "@angular/core";
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ViewPackagesComponent } from './view-packages/view-packages.component';
import { ViewPackageDetailsComponent } from './view-package-details/view-package-details.component';
import { BookPackageComponent } from './book-package/book-package.component';
import { BookAccomodationComponent } from './book-accomodation/book-accomodation.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { AddHotelComponent } from './add-hotel/add-hotel.component';
import { AddPackagesComponent } from './add-packages/add-packages.component';
import { AddVehicleComponent } from './add-vehicle/add-vehicle.component';
import { compileComponentFromMetadata } from '@angular/compiler';
import { AssigneeBoardComponent } from './assignee-board/assignee-board.component';
import { BookingHistoryComponent } from './booking-history/booking-history.component';
import { CustomerCareComponent } from './customer-care/customer-care.component';
import { ViewVehiclesComponent } from './view-vehicles/view-vehicles.component';
import { AuthGuardService } from './travelAway-services/auth-guard.service';
import { AuthGuardEmpService } from './travelAway-services/auth-guard-emp.service';
import { ReplyQueryComponent } from './reply-query/reply-query.component';
import { ViewHotelsComponent } from './view-hotels/view-hotels.component';
import { PaymentComponent } from './payment/payment.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'editProfile', component: EditProfileComponent, canActivate: [AuthGuardService] },
  { path: 'bookAccomodation', component: BookAccomodationComponent, canActivate: [AuthGuardService] },
  { path: 'payment', component: PaymentComponent, canActivate: [AuthGuardService] },
  { path: 'viewPackages', component: ViewPackagesComponent },
  { path: 'viewPackageDetails', component: ViewPackageDetailsComponent, canActivate: [AuthGuardService] },
  { path: 'addHotel', component: AddHotelComponent, canActivate: [AuthGuardEmpService] },
  { path: 'addPackages', component: AddPackagesComponent, canActivate: [AuthGuardEmpService] },
  { path: 'addVehicle', component: AddVehicleComponent, canActivate: [AuthGuardEmpService] },
  { path: 'viewAllVehicles', component: ViewVehiclesComponent, canActivate: [AuthGuardEmpService] },
  { path: 'viewAllHotels', component: ViewHotelsComponent, canActivate: [AuthGuardEmpService] },
  { path: 'assigneeBoard', component: AssigneeBoardComponent, canActivate: [AuthGuardEmpService] },
  { path: 'bookPackage', component: BookPackageComponent, canActivate: [AuthGuardService] },
  { path: 'bookingHistory', component: BookingHistoryComponent, canActivate: [AuthGuardService] },
  { path: 'customerCare', component: CustomerCareComponent, canActivate: [AuthGuardService] },
  { path: 'replyQuery', component: ReplyQueryComponent },
  { path: '**', component: HomeComponent }

];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
