import { Component, OnInit } from '@angular/core';
import { TravelawayService } from '../travelAway-services/travelaway.service';
import { Router } from '@angular/router';
import { IHotel } from '../travel-away-interfaces/IHotel';

@Component({
  selector: 'app-view-hotels',
  templateUrl: './view-hotels.component.html',
  styleUrls: ['./view-hotels.component.css']
})
export class ViewHotelsComponent implements OnInit {
  hotels: IHotel[];
  showMsgDiv: boolean = false;
  errMsg: string;
  userRole: string;
  msg: string;
  customerLayout: boolean = false;
  commonLayout: boolean = false;
  employeeLayout: boolean = false;

  constructor(private _travelservice: TravelawayService, private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;
  }

  ngOnInit(): void {
    this.getHotel();
    if (this.hotels == null) {
      this.showMsgDiv = true;
    }
  }

  getHotel() {
    this._travelservice.getHotels().subscribe(
      responseHotelData => {
        this.hotels = responseHotelData;

        this.showMsgDiv = false;
      },
      responseHotelError => {
        this.hotels = null;
        this.errMsg = responseHotelError;
        this.msg = "Try Again";
      },
      () => { console.log("GetAllHotels executed successfully") }
    );
  }

}
