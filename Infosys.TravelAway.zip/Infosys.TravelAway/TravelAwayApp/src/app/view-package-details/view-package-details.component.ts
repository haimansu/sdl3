import { Component, OnInit } from '@angular/core';
import { IPackageDetails } from 'src/app/travel-away-interfaces/packageDetails';
import { TravelawayService } from '../travelAway-services/travelaway.service';
import { NgForOf } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-package-details',
  templateUrl: './view-package-details.component.html',
  styleUrls: ['./view-package-details.component.css']
})
export class ViewPackageDetailsComponent implements OnInit {

  packageDetails: IPackageDetails[];
  errorMsg: string;
  showMsg: boolean = false;
  packageName: string;
  userRole: string;
  customerLayout: boolean = false;
  commonLayout: boolean = false;
  employeeLayout: boolean = false;

  constructor(private packageService: TravelawayService, private router: Router) {
    ///////////////add this in all component constructor along with the variables for the navbar
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;
    console.log(this.userRole);
  }

  ngOnInit(): void {
    this.packageName = sessionStorage.getItem('packageName');
    this.getPackageDetails(this.packageName);
    
  }


  getPackageDetails(packName:string) {
    this.packageService.getPackageDetails(packName).subscribe(
      responseGet => {
        this.showMsg = false;
        console.log(packName);
        this.packageDetails = responseGet;
        console.log(this.packageDetails);
        for (let pack of this.packageDetails) {
          console.log(pack.description);
        }
        
      },
      resonseError => {
        this.showMsg = true
        this.packageDetails = null
        this.errorMsg = resonseError
      },
      () => console.log("GetPackageDetails method executed")
    )
  }

  book() {
    this.router.navigate(['/bookPackage']);
  }

}
