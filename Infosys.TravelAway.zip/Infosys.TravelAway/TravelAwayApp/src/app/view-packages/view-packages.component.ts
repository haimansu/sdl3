import { Component, OnInit } from '@angular/core';
import { IPackage } from '../travel-away-interfaces/packages';
import { TravelawayService } from '../travelAway-services/travelaway.service';
import { IPackageCategory } from '../travel-away-interfaces/PackageCategory';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-packages',
  templateUrl: './view-packages.component.html',
  styleUrls: ['./view-packages.component.css']
})
export class ViewPackagesComponent implements OnInit {
  packages: IPackage[];
  categories: IPackageCategory[];
  filteredPackages: IPackage[];
  errorMsg: string;
  showMsg: boolean=false;
  imagePath: string;
  userRole: string;
  customerLayout: boolean = false;
  commonLayout: boolean = false;
  employeeLayout: boolean = false;
  //catName: string;

  constructor(private packageService: TravelawayService, private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;
    console.log(this.userRole);
  }

  ngOnInit(): void {
    this.getPackages();
    this.getPackageCategories();
    

    if (this.packages == null) {
      this.showMsg = true;
    }

    this.filteredPackages = this.packages;

    this.imagePath = "src/assets/"
  }

  getPackages() {
    this.packageService.getPackages().subscribe(
      responseGet => {
        this.showMsg = false;
        this.packages = responseGet;
        this.filteredPackages = responseGet; 
      },
      resonseError => {
        this.showMsg = true
        this.packages = null
        this.errorMsg = resonseError
      },
      () => console.log("GetPackage method executed")
    )
  }

  getPackageCategories() {
    this.packageService.getPackageCategories().subscribe(
      responseGet => {
        this.categories = responseGet
        console.log(this.categories)
      },
      responseError => {
        this.errorMsg = responseError
        this.categories = null
      },
      () => console.log("Getcategories executed")
    );
  }


  searchPackageByCategory(categoryId: string) {
    this.filteredPackages = this.packages;
    if (categoryId == "0") {
      this.filteredPackages = this.packages;
    }
    else {
      this.filteredPackages = this.filteredPackages.filter(pack => pack.categoryId.toString() == categoryId);
    }
  }


  viewPackageDetails(pack: number,packName:string) {
   //- console.log(pack);
    sessionStorage.setItem('packageId', pack.toString());
    sessionStorage.setItem('packageName', packName);
   // this.router.navigate(['/viewPackageDetails']);
  }
}
