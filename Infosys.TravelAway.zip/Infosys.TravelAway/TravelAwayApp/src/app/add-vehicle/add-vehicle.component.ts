import { Component, OnInit } from '@angular/core';
import { IVehicle } from '../travel-away-interfaces/vehicle';
import { TravelawayService } from '../travelAway-services/travelaway.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-vehicle',
  templateUrl: './add-vehicle.component.html',
  styleUrls: ['./add-vehicle.component.css']
})
export class AddVehicleComponent implements OnInit {
  vehicleId: number;
  commonLayout: boolean = false;
  customerLayout: boolean = false;
  employeeLayout: boolean = false;
  userRole: string;
  addVehicleForm: FormGroup;
  basePrice: number;
  validForm: boolean = true;

  constructor(private _packageService: TravelawayService, private router: Router, private formBuilder: FormBuilder) {

    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;
  }

  ngOnInit(): void {
    this.addVehicleForm = this.formBuilder.group({
      vehicleName: ['', Validators.required],
      vehicleType: ['', Validators.required],
      ratePerHour: ['', Validators.required],
      ratePerKm: ['', Validators.required]

    })
  }
  SubmitForm(form: FormGroup) {
    console.log(form.value.vehicleName, form.value.vehicleType, form.value.ratePerHour, form.value.ratePerKm);
    if (form.value.vehicleType == "Two-Wheeler")
      this.basePrice = 100;
    else if (form.value.vehicleType == "Four-Wheeler")
      this.basePrice = 200;
    else
      this.basePrice = 350;
    if (this.addVehicleForm.valid) {
      this.validForm = false;
      this._packageService.addVehicle(form.value.vehicleName, form.value.vehicleType, parseInt(form.value.ratePerHour), parseInt(form.value.ratePerKm), this.basePrice).subscribe(
        responseVehicle => {
          this.vehicleId = responseVehicle;
          if (this.vehicleId > 0) {
            alert("Vehicle details added succesfully with Vehicle ID:" + this.vehicleId);
            this.router.navigate(['/viewAllVehicles']);
          }
          else {
            alert("Vehicle details not added please try again");
            this.router.navigate(['/addVehicle'])
          }
        },
        responseErrorStatus => {
          this.vehicleId = responseErrorStatus;
          alert("Vehicle details not added please try again");
        },
        () => { console.log("addVehicleForm Submitted successfully") }
      );
    }
    else {
      alert("Please Enter valid details");
    }
  }

}
