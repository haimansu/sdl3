import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ICustomer } from '../travel-away-interfaces/customer';
import { TravelawayService } from '../travelAway-services/travelaway.service';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  email: string
  cust: ICustomer;
  updateCust: ICustomer;
  editForm: FormGroup;
  status: boolean;
  fname: string;
  lname: string;
  gender: string
  cno: number
  add: string
  constructor(private service: TravelawayService, private formBuilder: FormBuilder, private route: Router) { }

  ngOnInit(): void {
    this.email = sessionStorage.getItem('userName');
    if (this.email == null) {
      this.route.navigate(['/login']);
    }
    this.service.getCustomerByEmail(this.email).subscribe(
      res => {
        
        this.fname = res.firstName
        this.lname = res.lastName
        this.gender = res.gender
        this.cno = res.contactNo
        this.add = res.address
        this.cust = res;
        console.log("i'm here...." + res['dateofbirth']);
        this.FillForm(res);
      },
      b => {
        console.log(b);
      }
    );
 var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    var unamePattern: string = "^[A-Za-z]*$";
    var conpattern = "^[1-9][0-9]*$";
    this.editForm = this.formBuilder.group(
      {
        
        firstName: ['', [Validators.required, Validators.pattern(unamePattern)]],
        lastName: ['', [Validators.required, Validators.pattern(unamePattern)]],
        password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(16)]],
        //confirmpassword: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(16)]],
        gender: ['', Validators.required],
        contactNo: ['', [Validators.required, Validators.min(1000000000), Validators.max(9999999999), Validators.pattern(conpattern)]],
        dateofbirth: ['', [Validators.required, checkDate]],
        address: ['', Validators.required]
      });
  }
  FillForm(cust: ICustomer) {
        this.editForm.patchValue({
      firstName: cust.firstName,
      lastName: cust.lastName,
      gender: cust.gender,
      contactNo: cust.contactNo,
      dateofbirth: cust.dateOfBirth,
      address: cust.address
    })
  }
  submitEditForm(form: FormGroup) {
    this.updateCust = {
      emailId: this.email,
      firstName: form.value.firstName,
      lastName: form.value.lastName,
      password: form.value.password,
      gender: form.value.gender,
      contactNo: parseInt(form.value.contactNo),
      dateOfBirth: form.value.dateOfBirth,
      address: form.value.address,
      roleId: 1
    }
    console.log(form.value.contactNo)
    this.service.editProfile(this.updateCust).subscribe(
      res => {
        this.status = res;
        if (this.status == true) {
          console.log('update successful');
          alert('Your details have been successfully updated')
          this.route.navigate(['/home']);
        }
        else {
          alert('something went wrong')
        }
      },
      b => {
        console.log(b);
      }
    );
  }

  GoToHome() {
    confirm('Your changes are not saved.Do you want to leave?')
    this.route.navigate(['/home']);
  }
}
function checkDate(control: FormControl) {
  var currentDate = new Date();
  var givenDate = new Date(control.value)
  console.log(currentDate);
  console.log(givenDate);
  if (givenDate <= currentDate || givenDate == null) {
    return null
  }
  else {
    return {
      dateError: {
        message: "Enter a date less than today's date"
      }
    };
  }
}


