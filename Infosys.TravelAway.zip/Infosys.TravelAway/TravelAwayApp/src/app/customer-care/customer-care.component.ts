import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';
import { ICustomerCare } from '../travel-away-interfaces/customerCare';
import { TravelawayService } from '../travelAway-services/travelaway.service';
@Component({
  selector: 'app-customer-care',
  templateUrl: './customer-care.component.html',
  styleUrls: ['./customer-care.component.css']
})
export class CustomerCareComponent implements OnInit {
  msg: string;
  userRole: string;
  customerLayout: boolean = false;
  commonLayout: boolean = false;
  employeeLayout: boolean = false;
  errorMsg: any;
  showMsg: boolean;
  status: string;
  showDiv: boolean = false;
  customerCareForm: FormGroup;
  queries: ICustomerCare[];
  cstatus: boolean = false;
  showtable: boolean = false;

  constructor(private formBuilder: FormBuilder, private _userService: TravelawayService, private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;}

  ngOnInit(): void {
    this.getQueryList();
    this.customerCareForm= this.formBuilder.group({
      query: ['', Validators.required],
      bookingId: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5), Validators.pattern("[100]{3}[0-9]{2}")]]
    })

  }

  getQueryList() {
    this._userService.getQueries().subscribe(
      responseGet => {
        this.showMsg = false;
        this.queries = responseGet;
        if (this.queries.length>0)
          this.showtable = true;
      },
      resonseError => {
        this.showMsg = true
        this.queries = null
        this.errorMsg = resonseError
        this.showtable = false
      },
      () => console.log("GetQueries method executed")
    )
  }

  SubmitForm(form: FormGroup) {
    console.log(form.value.query, form.value.bookingId);

    this._userService.RegisterQuery(form.value.query, parseInt(form.value.bookingId)).subscribe(
      responseQueryStatus => {
        this.status = responseQueryStatus;
        console.log(this.status);
        if (this.status == "query registered") {

          this.msg = "Query Submitted Successfully";
          alert(this.msg);
          this.router.navigate(['/customerCare']);
        }
        else {
          this.msg = "Unable to Submit Query.";
          alert(this.msg);
          this.router.navigate(['/customerCare']);
        }
      },
      responseSubmitError => {
        this.errorMsg = responseSubmitError;
        console.log(this.errorMsg);
      },
      () => { console.log("RegisterQuery Method executed successfully"); }
    );
    this.router.navigate(['/customerCare']);
  }
  close(queryId: number) {
    console.log(queryId);
    this._userService.closeQuery(queryId).subscribe(
      responseClose => {
        this.cstatus = responseClose;
        if (this.cstatus == true) {
          this.msg = "Query Closed!";
          alert(this.msg);
          this.router.navigate(['/customerCare']);
        }
        else {
          this.msg = "Unable to Close Query.";
          alert(this.msg);
          this.router.navigate(['/customerCare']);
        }
      }
    );
    this.router.navigate(['/customerCare']);
  }

}
