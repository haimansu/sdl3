
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';
import { TravelawayService } from '../travelAway-services/travelaway.service';
import { stat } from 'fs';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  msg: string;
  userRole: string;
  customerLayout: boolean = false;
  commonLayout: boolean = false;
  employeeLayout: boolean = false;
  errorMsg: any;
  status: number;
  showDiv: boolean = false;
  role: number = 1;
  constructor(private formBuilder: FormBuilder, private _userService: TravelawayService, private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;
  }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
      lastName: ['', [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
      emailId: ['', [Validators.required, Validators.minLength(12), Validators.maxLength(40), Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],
      gender: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(16)]],
      confirmPassword: ['', [Validators.required]],
      dateOfbirth: ['', [Validators.required, checkDate]],
      address: ['', Validators.required],
      contactNumber: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern("[1-9]{1}[0-9]{9}")]]
    })
  }



  SubmitForm(form: FormGroup) {

    //console.log("******");
    //console.log(form.value.firstName);
    //console.log("******");
    //console.log(form.value.emailId, form.value.password, form.get('gender').value,
    //  form.value.dateOfbirth, form.value.address, form.value.contactNumber);
    //if (this.registerForm.valid) {
    //  this.msg = "Signup Successful"
    //}
    //else {
    //  this.msg = "Try again Later"
    //}

    this._userService.addUserDetails(this.role, this.registerForm.value.firstName, this.registerForm.value.lastName, this.registerForm.value.emailId, this.registerForm.value.password, this.registerForm.value.gender, this.registerForm.value.dateOfbirth, parseInt(this.registerForm.value.contactNumber), this.registerForm.value.address).subscribe(
      resposeRegisterStatus => {
        console.log(this.registerForm.value.firstName);
        console.log(this.registerForm.value.lastName);
        console.log(this.registerForm.value.emailId)
        console.log(this.registerForm.value.password);
        console.log(this.registerForm.get('gender').value);
        console.log(this.registerForm.value.dateOfbirth);
        console.log(this.registerForm.value.contactNumber);
        console.log(this.registerForm.value.address);


        this.status = resposeRegisterStatus;
        console.log(this.status);
        if (this.status == 0) {
          this.msg = "Registered successfully";
          alert("Your registration is successful. You are now being forwarded to login page.");
          this.router.navigate(['/login']);
        }
        else if (this.status == -1) {
          this.msg = "Registered Failed";
          alert("Your registration is unsuccessful. Please enter a valid EmailId");
          this.router.navigate(['/register']);
        }
        else if (this.status == -2) {
          this.msg = "Registered Failed";
          alert("Your registration is unsuccessful. Please check your password and try again");
          this.router.navigate(['/register']);
        }
        else if (this.status == -3 || this.status == -4) {
          this.msg = "Registered Failed";
          alert("Your registration is unsuccessful. Please ensure the Date you entered is correct");
          this.router.navigate(['/register']);
        }
        else if (this.status == -5) {
          this.msg = "Registered Failed";
          alert("Your registration is unsuccessful. Please enter a valid Name");
          this.router.navigate(['/register']);
        }

      },
      resposeRegisterError => {
        this.errorMsg = resposeRegisterError;
        this.msg = "Try again!"
        this.router.navigate(['/register']);
      },
      () => console.log("SubmitRegister method executed successfully")
    );
  }


}

function checkDate(control: FormControl) {
  var currentDate = new Date();
  var givenDate = new Date(control.value)
  console.log(currentDate);
  console.log(givenDate);
  if (givenDate <= currentDate || givenDate == null) {
    return null
  }
  else {
    return {
      dateError: {
        message: "Enter a date less than today's date"
      }
    };
  }
}
