import { Component, OnInit } from '@angular/core';
import { TravelawayService } from '../travelAway-services/travelaway.service';
import { Router } from '@angular/router';
import { IVehicle } from '../travel-away-interfaces/vehicle';

@Component({
  selector: 'app-view-vehicles',
  templateUrl: './view-vehicles.component.html',
  styleUrls: ['./view-vehicles.component.css']
})
export class ViewVehiclesComponent implements OnInit {
  userRole: string;
  customerLayout: boolean = false;
  commonLayout: boolean = false;
  employeeLayout: boolean = false;
  vehicles: IVehicle[];
  errorMsg: string;
  msg: string;
  showMessageDiv: boolean = false;

  constructor(private _userService: TravelawayService, private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;
  }

  ngOnInit(): void {
    this.GetVehicles();
    if (this.vehicles == null) {
      this.showMessageDiv = true;
    }
  }
  GetVehicles() {
    this._userService.GetAllVehicles().subscribe(
      responseVehicleStatus => {
        this.vehicles = responseVehicleStatus;
        this.showMessageDiv = false;
      },
      responseErrorStatus => {
        this.errorMsg = responseErrorStatus;
        this.msg = "Try Again";
      },
      () => { console.log("GetAllVehicles executed successfully") }
    );
  }
}
