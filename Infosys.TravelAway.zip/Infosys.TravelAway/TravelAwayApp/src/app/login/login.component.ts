
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { TravelawayService } from '../travelAway-services/travelaway.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Local } from 'protractor/built/driverProviders';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  status: string;
  errorMsg: string;
  msg: string;
  showDiv: boolean = false;
  name: string;
  customerLayout: boolean = false;
  employeeLayout: boolean = false;
  commonLayout: boolean = true;
  userRole: string;
  thisimageSrc: string = "./assets/banner.jpg";
//  userName: string;

  constructor(private _userService: TravelawayService, private router: Router, private route: ActivatedRoute) {
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;
    console.log(this.userRole);
  }

  submitLoginForm(form: NgForm) {
    console.log(form.value.email);
    console.log(form.value.password);
    this._userService.validateCredentials(form.value.email, form.value.password).subscribe(
      responseLoginStatus => {
        //console.log("Inside response");
        this.status = responseLoginStatus;
        console.log(this.status);
        this.showDiv = true;
        if (this.status == "Employee") {
          this.msg = "Login Successful";
          sessionStorage.setItem('userName', form.value.email);
        //  localStorage.setItem('email', form.value.email);
          sessionStorage.setItem('userRole', "Employee");
          this.router.navigate(['/home']);
        }
        else if (this.status == "Customer") {
          sessionStorage.setItem('userName', form.value.email);
          sessionStorage.setItem('userRole', "Customer");
          this.router.navigate(['/home']);
        }
        else {
          this.msg = "Try again with valid credentials";
        }

      },
      responseLoginError => {
        //console.log("Inside error");
        this.errorMsg = responseLoginError;
        console.log(this.errorMsg);
      },
      () => console.log("SubmitLoginForm method executed successfully")
    );


  }

  ngOnInit() {
  }

}
