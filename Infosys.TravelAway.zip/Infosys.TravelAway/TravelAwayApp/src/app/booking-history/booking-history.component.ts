import { Component, OnInit } from '@angular/core';
import { TravelawayService } from '../travelAway-services/travelaway.service';
import { Router } from '@angular/router';
import { IBooking } from '../travel-away-interfaces/booking';
import { IPackage } from '../travel-away-interfaces/packages';
import { error } from 'console';

@Component({
  selector: 'app-booking-history',
  templateUrl: './booking-history.component.html',
  styleUrls: ['./booking-history.component.css']
})
export class BookingHistoryComponent implements OnInit {
  userRole: string;
  customerLayout: boolean = false;
  commonLayout: boolean = false;
  employeeLayout: boolean = false;
  bookings: IBooking[];
  packageDetails: IPackage[] = [];
  package: IPackage;
  errorMsg: string;
  msg: string;
  constructor(private _userService: TravelawayService, private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;
  }

  ngOnInit(): void {
    this.GetBookings();
  }
  GetBookings() {
    this._userService.BookingHistory().subscribe(
      responseBookings => {
        this.bookings = responseBookings;
        console.log(this.bookings);
        this.GetPackages();
      },
      responseBookingError => {
        this.errorMsg = responseBookingError;
        this.msg = "Try Again!";
      },
      () => console.log("GetBookings Method Executed Successfully")
    );
    if (this.bookings != null && this.bookings.length > 0)
      this.GetPackages();
  }
  GetPackages() {
    for (let book of this.bookings) {
      this._userService.getPackageById(book.packageId).subscribe(
        responsePackage => {
          this.package = responsePackage;
          if (this.package != null)
            this.packageDetails.push(responsePackage);
          //console.log(this.packageDetails);
        },
        responsePackageError => {
          this.errorMsg = responsePackageError;
          console.log(this.errorMsg);
        },
        () => console.log("GetPackageById method executed successfully")
      );
    }
    console.log(this.packageDetails);
  }
  setPackageName(packName: string, packId: string) {
    sessionStorage.setItem('packageName', packName);
    sessionStorage.setItem('packageId', packId);
  }
}
