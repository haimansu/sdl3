import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-layout',
  templateUrl: './customer-layout.component.html',
  styleUrls: ['./customer-layout.component.css']
})
export class CustomerLayoutComponent implements OnInit {
  userRole: string;
  userName: string;
  logo: string;
  img1: string;
  img2: string;
  img3: string;
  constructor(private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    this.userName = sessionStorage.getItem('userName');
    this.logo = "assets/logo.png";
    this.img1 = "assets/1.png";
    this.img2 = "assets/2.png";
    this.img3 = "assets/3.png";
  }
  logOut() {
    sessionStorage.clear();
    //sessionStorage.removeItem('userRole');
    //sessionStorage.removeItem('userName');
    this.router.navigate(['/home']);
  }
  ngOnInit(): void {
  }

}
