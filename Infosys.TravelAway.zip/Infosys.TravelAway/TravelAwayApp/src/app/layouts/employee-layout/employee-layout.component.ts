import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-employee-layout',
  templateUrl: './employee-layout.component.html',
  styleUrls: ['./employee-layout.component.css']
})
export class EmployeeLayoutComponent implements OnInit {
  userRole: string;
  userName: string;
  logo: string;
  constructor(private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    this.userName = sessionStorage.getItem('userName');
  }
  logOut() {
    sessionStorage.clear();
    //sessionStorage.removeItem('userRole');
    //sessionStorage.removeItem('userName');
    this.router.navigate(['/home']);
  }


  ngOnInit(): void {
    this.logo = "./assets/logo.png";
  }

}
