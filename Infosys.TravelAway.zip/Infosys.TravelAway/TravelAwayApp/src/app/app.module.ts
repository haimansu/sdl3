import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ViewPackagesComponent } from './view-packages/view-packages.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { routing } from './app.routing';
import { CommonLayoutComponent } from './layouts/common-layout/common-layout.component';
import { CustomerLayoutComponent } from './layouts/customer-layout/customer-layout.component';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { TravelawayService } from './travelAway-services/travelaway.service';
import { BookPackageComponent } from './book-package/book-package.component';
import { BookAccomodationComponent } from './book-accomodation/book-accomodation.component';
import { EmployeeLayoutComponent } from './layouts/employee-layout/employee-layout.component';
import { CommonModule } from '@angular/common';
import { ViewPackageDetailsComponent } from './view-package-details/view-package-details.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { CustomerCareComponent } from './customer-care/customer-care.component';
import { AssigneeBoardComponent } from './assignee-board/assignee-board.component';
import { AddHotelComponent } from './add-hotel/add-hotel.component';
import { AddPackagesComponent } from './add-packages/add-packages.component';
import { AddVehicleComponent } from './add-vehicle/add-vehicle.component';
import { BookingHistoryComponent } from './booking-history/booking-history.component';
import { ViewVehiclesComponent } from './view-vehicles/view-vehicles.component';
import { ReplyQueryComponent } from './reply-query/reply-query.component';
import { ViewHotelsComponent } from './view-hotels/view-hotels.component';
import { PaymentComponent } from './payment/payment.component';

@NgModule({
  declarations: [
    AppComponent,
    ViewPackagesComponent,ReplyQueryComponent,CommonLayoutComponent, HomeComponent, CustomerLayoutComponent, CustomerCareComponent, BookPackageComponent, BookAccomodationComponent,LoginComponent,RegisterComponent, EmployeeLayoutComponent,ViewPackageDetailsComponent, EditProfileComponent, AssigneeBoardComponent, AddHotelComponent, AddPackagesComponent, AddVehicleComponent, BookingHistoryComponent, ViewVehiclesComponent, ViewHotelsComponent, PaymentComponent
  ],
  imports: [
    BrowserModule,CommonModule,
    AppRoutingModule,FormsModule, ReactiveFormsModule, HttpClientModule, routing
  ],
  providers: [TravelawayService],
  bootstrap: [AppComponent]
})
export class AppModule { }
