import { Component, OnInit } from '@angular/core';
import { TravelawayService } from '../travelAway-services/travelaway.service';
import { IPackage } from '../travel-away-interfaces/packages';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-packages',
  templateUrl: './add-packages.component.html',
  styleUrls: ['./add-packages.component.css']
})
export class AddPackagesComponent implements OnInit {
  package: IPackage[];
  errMsg: string;
  addPackageForm: FormGroup;
  msg: string;
  pId: number;
  commonLayout: boolean = false;
  customerLayout: boolean = false;
  employeeLayout: boolean = false;
  userRole: string;

  constructor(private packageService: TravelawayService, private formBuilder: FormBuilder, private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "Customer")
      this.customerLayout = true;
    else if (this.userRole == "Employee")
      this.employeeLayout = true;
    else
      this.commonLayout = true;
  }

  ngOnInit(): void {
    this.addPackageForm = this.formBuilder.group({
      packageName: ['', Validators.required],
      packageInfo: ['', Validators.required],
      categoryId: ['', Validators.required],
      packageType: ['', Validators.required]
    })
  }
  SubmitForm(form: FormGroup) {
    console.log(form.value.packageName, form.value.packageInfo, form.value.packageType, form.value.categoryId);
    this.packageService.addPackages(form.value.packageName, form.value.packageInfo, form.value.packageType, parseInt(form.value.categoryId))
      .subscribe(
        responseData => {
          this.pId = responseData;
          if (this.pId > 0) {
            this.msg = "Package added successfully";
            sessionStorage.setItem('pId', this.pId.toString());
            alert("Package added sucessfully.");
            this.router.navigate(['/viewPackages']);
          }
          else {
            this.msg = "Unsuccessful";
            alert("Something went wrong.Please try again later");
            this.router.navigate(['/addPackages']);
          }
        },
        responseError => {
          this.errMsg = responseError,
            console.log(this.errMsg),
            alert("Sorry, something went wrong. Please try again after sometime.")
        },
        () => console.log("AddPackages method executed successfully")
      );
  }


}
