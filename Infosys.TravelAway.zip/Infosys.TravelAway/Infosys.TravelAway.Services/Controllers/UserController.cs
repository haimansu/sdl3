﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Infosys.TravelAway.DataAccessLayer;
using Infosys.TravelAway.DataAccessLayer.Models;

namespace Infosys.TravelAway.Services.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : Controller
    {
        TravelAwayRepository repos;
        public UserController()
        {
            repos = new TravelAwayRepository();
        }

        [HttpPost]
        public JsonResult ValidateLogin(Customer usr)
        {
            //Console.WriteLine(emailId);
            string emailId = usr.EmailId;
            string password = usr.Password;
            string user;
            try
            {
                user = repos.Login(emailId, password);
            }
            catch (Exception ex)
            {
                
                Console.WriteLine(ex.Message);
                throw;
            }
            return Json(user);
        }

        [HttpGet]
        public JsonResult GetAllPackages()
        {
            List<Package> packages = new List<Package>();
            try
            {
                packages = repos.GetAllPackagesusingTVF();
            }
            catch (Exception)
            {
                packages = null;
            }
            return Json(packages);
        }

        [HttpGet]
        public JsonResult GetAllPackageCategory()
        {
            List<PackageCategory> packages = new List<PackageCategory>();
            try
            {
                packages = repos.GetAllPackageCategories();
            }
            catch (Exception)
            {
                packages = null;
            }
            return Json(packages);
        }


        [HttpGet]
        public JsonResult GetPackageByCategoryName(string categoryName)
        {
            List<Package> package = new List<Package>();
            try
            {
                package = repos.GetPackageByCategoryName(categoryName);
            }
            catch (Exception)
            {
                package = null;
            }
            return Json(package);
        }



        [HttpGet]
        public JsonResult GetPackageDetails(string packageName)
        {
            List<PackageDetails> package = new List<PackageDetails>();
            try
            {
                package = repos.GetAllPackageDetails(packageName);
            }
            catch (Exception)
            {
                package = null;
            }
            return Json(package);
        }

        [HttpPost]
        public int AddRegistration(Customer cust)
        {
            int status = 0;
            try
            {
                //Infosys.TravelAway.DataAccessLayer.Models.Customer cust = new Infosys.TravelAway.DataAccessLayer.Models.Customer();
                //cust.EmailId = email;
                //cust.FirstName = fName;
                //cust.LastName = lName;
                //cust.Password = password;
                //cust.Gender = gender;
                //cust.ContactNo = contact;
                //cust.DateOfBirth = dob;
                //cust.Address = address;
                status = repos.Registration(cust.EmailId, cust.FirstName, cust.LastName, cust.Password, cust.Gender, cust.ContactNo, cust.DateOfBirth, cust.Address);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                status = 0;
            }
            return status;
        }

        [HttpPut]
        public bool EditProfile(Customer cust1)
        {
            bool status;
            try
            {
                status = repos.EditProfile(cust1);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                status = false;
            }
            return status;
        }
        public bool AddRating(Rating rate)
        {
            bool status = false;
            try
            {
                Infosys.TravelAway.DataAccessLayer.Models.Rating rating = new Infosys.TravelAway.DataAccessLayer.Models.Rating();
                rating.Review = rate.Review;
                rating.Rating1 = rate.Rating1;
                rating.BookingId = rate.BookingId;
                status = repos.Rating(rating);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                status = false;
            }
            return status;
        }
        public bool Payment(Payment pay)
        {
            bool status = false;
            try
            {
                Infosys.TravelAway.DataAccessLayer.Models.Payment payment = new Infosys.TravelAway.DataAccessLayer.Models.Payment();
                payment.BookingId = pay.BookingId;
                payment.TotalAmount = pay.TotalAmount;
                payment.PaymentStatus = pay.PaymentStatus;
                status = repos.Payment(payment);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                status = false;
            }
            return status;
        }

        ///////////////////////RATHEESH CODE START/////////////////////////////////////
        [HttpPost]
        public JsonResult BookPackage(Booking newBooking)
        {
            int status = 0;
            //Booking newBooking = new Booking();
            try
            {
                //var emailId = Url.RouteUrl.RouteData.Values["Id"];
                //newBooking.EmailId = emailId;
                //newBooking.PackageId = packageId;
                //newBooking.ContactNo = contactNo;
                //newBooking.Address = address;
                //newBooking.TravelDate = dateOfTravel;
                //newBooking.Status = bookingStatus;
                //newBooking.NoOfAdults = noOfAdults;
                //newBooking.NoOfChildren = noOfChildren;
                status = repos.BookPackage(newBooking);
            }
            catch (Exception)
            {
                status = -1;

            }
            return Json(status);
        }
        [HttpGet]
        public List<Booking> BookingHistory(string emailId)
        {
            List<Booking> bookings = new List<Booking>();
            try
            {
                bookings = repos.BookingHistory(emailId);
            }
            catch (Exception)
            {

                bookings = null;
            }
            return bookings;
        }
        [HttpGet]
        public Package GetPackageById(string packageId)
        {
            Package pack = new Package();
            try
            {
                pack = repos.GetPackageById(packageId);
            }
            catch (Exception)
            {

                pack = null;
            }
            return pack;
        }
        [HttpPost]
        public JsonResult BookAccomodation(Accomodation newAccomodation)
        {
            int status = 0;
            // Accomodation newAccomodation = new Accomodation();
            try
            {
                status = repos.BookAccomodation(newAccomodation);
                //status = true;
            }
            catch (Exception)
            {
                //Console.WriteLine(e.Message);
                status = -1;
            }
            return Json(status);
        }

        [HttpGet]
        public JsonResult GetAllHotels()
        {
            List<Hotel> hotels = new List<Hotel>();
            try
            {
                hotels = repos.GetAllHotels();
            }
            catch (Exception)
            {
                hotels = null;
            }
            return Json(hotels);
        }
        [HttpPost]
        public int AddVehicle(Vehicle vehicle)
        {
            int vehicleId = 0;
            try
            {
                vehicleId = repos.AddVehicle(vehicle);
            }
            catch (Exception)
            {

                vehicleId = -1;
            }
            return vehicleId;
        }

        [HttpPost]
        public int AddPackage(Package pack)
        {
            int pId = 0;
            try
            {
                pId = repos.AddPackage(pack);
            }
            catch (Exception)
            {

                pId = -1;
            }
            return pId;
        }
        [HttpGet]
        public JsonResult GetAllVehicles()
        {
            List<Vehicle> vehicles = new List<Vehicle>();
            try
            {
                vehicles = repos.GetAllVehicles();
            }
            catch (Exception)
            {

                vehicles = null;
            }
            return Json(vehicles);
        }
        ///////////////////////RATHEESH CODE END/////////////////////////////////////
        [HttpPost]
        public JsonResult RegisterQuery(CustomerCare cc)
        {
            string status;
            try
            {
                CustomerCare cc1 = new CustomerCare();
                string question = cc.Query;
                int bId = (int)cc.BookingId;
                status = repos.RegisterQuery(question,bId);
            }
            catch (Exception)
            {
                status = "Could not register";
            }
            return Json(status);
        }
        [HttpPut]
        public JsonResult AnsQuery(CustomerCare cc)
        {
            string status;
            try
            {
                CustomerCare cc1 = new CustomerCare();
                string ans = cc.QueryAns;
                int qId= cc.QueryId;
                status = repos.AnsQuery(ans,qId);
            }
            catch (Exception)
            {
                status = "Could not register answer";
            }
            return Json(status);
        }
        [HttpGet]
        public JsonResult GetQueries(string email)
        {
            List<CustomerCare> queries = new List<CustomerCare>();
            try
            {
                queries = repos.GetQueries(email);
            }
            catch (Exception)
            {
                queries = null;
            }
            return Json(queries);
        }
        [HttpGet]

        public JsonResult CustomerByEmailId(string email)
        {
            List<Customer> cc = new List<Customer>();
            try
            {
                cc = repos.CustomerByEmailId(email);

            }
            catch (Exception)
            {
                cc = null;
            }
            return Json(cc);
        }


        [HttpGet]
        public JsonResult EmpGetQueries(string email)
        {
            List<CustomerCare> queries = new List<CustomerCare>();
            try
            {
                queries = repos.EmpGetQueries(email);
            }
            catch (Exception)
            {
                queries = null;
            }
            return Json(queries);
        }

        [HttpPost]
        public JsonResult AddHotels(Hotel hotel)
        {
            int status;
            

            try
            {
                status = repos.AddHotels(hotel);

            }
            catch (Exception)
            {
                status = -1;
                
            }
            return Json(status);
        }
         
        [HttpPut]
        public bool Close(CustomerCare cc)
        {
            bool status;
            try
            {
                status = repos.Close(cc.QueryId);
                
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
    }
}
